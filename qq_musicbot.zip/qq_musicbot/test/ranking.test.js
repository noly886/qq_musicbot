import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { MusicBot, formatRequestRanking } from '../src/bot.js';
import { RuntimeStore } from '../src/store.js';

function createStore() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'musicbot-ranking-'));
  return { directory, store: new RuntimeStore(path.join(directory, 'runtime.json')) };
}

test('request ranking counts songs per group and persists', () => {
  const { directory, store } = createStore();
  try {
    const first = store.addMusicRequest({ groupId: '10001', userId: '1', title: 'Song A' });
    const second = store.addMusicRequest({ groupId: '10001', userId: '2', title: 'song a' });
    const third = store.addMusicRequest({ groupId: '10001', userId: '3', title: 'Song B' });
    assert.equal(first.total, 1);
    assert.equal(second.entries[0].count, 2);
    assert.equal(third.total, 3);
    assert.deepEqual(third.entries.map(({ title, count }) => ({ title, count })), [
      { title: 'song a', count: 2 },
      { title: 'Song B', count: 1 }
    ]);
    const reloaded = new RuntimeStore(path.join(directory, 'runtime.json'));
    assert.equal(reloaded.state.requestRankings['10001'].total, 3);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('bot sends ranking from the second music command', async () => {
  const replies = [];
  const rankings = [];
  const bot = new MusicBot({
    config: { command: '/music', allowedGroups: [] },
    napcat: { on() {}, async sendGroupMessage(_groupId, message) { replies.push(message); } },
    bridge: { async hasActiveCall() { return false; } },
    library: { search() { return []; } },
    kugou: null,
    logger: { info() {}, error() {} },
    store: {
      state: { current: null },
      increment() {},
      addMusicRequest(request) {
        rankings.push(request);
        return { total: rankings.length, entries: rankings.map((item) => ({ title: item.title, count: 1 })) };
      }
    },
    subscribe: false
  });

  await bot.execute({ groupId: '10001', userId: '1', argument: 'Song A' });
  assert.equal(replies.some((message) => message.includes('点歌排行榜')), false);
  await bot.execute({ groupId: '10001', userId: '2', argument: 'Song B' });
  assert.equal(replies.some((message) => message.includes('点歌排行榜')), true);
  assert.match(formatRequestRanking({ total: 2, entries: [{ title: 'Song A', count: 2 }] }), /Song A · 2 次/);
});
