import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { ShareRoomService } from '../src/share-room-service.js';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

test('share room streams audio and closes when bridge playback ends', async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'musicbot-room-'));
  const file = path.join(directory, 'track.mp3');
  fs.writeFileSync(file, Buffer.from('0123456789'));
  let playback = { active: true, supported: true, playbackId: 'play-1', groupId: '10001' };
  const service = new ShareRoomService({
    enabled: true,
    host: '127.0.0.1',
    port: 0,
    publicBaseUrl: '',
    maxLifetimeMs: 60000
  }, {
    async playback() { return playback; }
  }, {
    success() {},
    warn() {}
  }, projectRoot);

  try {
    await service.start();
    const room = service.create({
      groupId: '10001',
      userId: '20002',
      track: { title: 'Test Track', file, format: 'MP3', lyrics: [{ time: 3, text: 'First line' }] },
      playback: { playbackId: 'play-1', startedAt: new Date().toISOString() }
    });
    const port = service.server.address().port;
    const baseUrl = `http://127.0.0.1:${port}`;
    const status = await fetch(`${baseUrl}/api/rooms/${room.token}`).then((response) => response.json());
    assert.equal(status.active, true);
    assert.equal(status.title, 'Test Track');
    assert.equal(status.group, '***0001');
    assert.deepEqual(status.lyrics, [{ time: 3, text: 'First line' }]);

    const mediaResponse = await fetch(`${baseUrl}/media/${room.token}`, { headers: { range: 'bytes=2-5' } });
    assert.equal(mediaResponse.status, 206);
    assert.equal(await mediaResponse.text(), '2345');

    playback = { active: false, supported: true };
    await service.monitor();
    const ended = await fetch(`${baseUrl}/api/rooms/${room.token}`).then((response) => response.json());
    assert.equal(ended.active, false);
    assert.equal((await fetch(`${baseUrl}/media/${room.token}`)).status, 410);
  } finally {
    await service.stop();
    fs.rmSync(directory, { recursive: true, force: true });
  }
});
