import assert from 'node:assert/strict';
import test from 'node:test';
import { decodeEscapedText, extractKugouUrl, isKugouInput, KugouService } from '../src/kugou-service.js';

test('decodes escaped Unicode text returned by Kugou share pages', () => {
  assert.equal(decodeEscapedText('\\u738b\\u4ee5\\u592a'), '王以太');
  assert.equal(decodeEscapedText('\\\\u522b\\\\u6015'), '别怕');
});

test('extracts a Kugou link from shared text', () => {
  const input = '分享一首歌曲给你：https://m.kugou.com/song/abc.html?hash=HASH123，打开酷狗收听';
  assert.equal(extractKugouUrl(input).searchParams.get('hash'), 'HASH123');
  assert.equal(isKugouInput(input), true);
  assert.equal(isKugouInput('https://example.com/song/1'), false);
});

test('resolves a Kugou page hash into a downloadable track', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(`
    <html><head><meta property="og:title" content="Singer - Direct Song - 酷狗音乐"></head>
    <body><script>window.data={"hash":"DIRECT_HASH","album_id":"ALBUM_1","audio_id":"AUDIO_1","song_name":"\\u0053inger - \\u0044irect Song","author_name":"\\u0053inger"}</script></body></html>
  `, { status: 200, headers: { 'content-type': 'text/html' } });
  try {
    const service = new KugouService({ sessionFile: 'unused.json' }, { warn() {} });
    service.cookies = { token: 'token', userid: '1' };
    service.download = async (track) => track;
    const track = await service.resolve('https://m.kugou.com/song/direct.html');
    assert.equal(track.hash, 'DIRECT_HASH');
    assert.equal(track.albumId, 'ALBUM_1');
    assert.equal(track.albumAudioId, 'AUDIO_1');
    assert.equal(track.title, 'Direct Song');
    assert.equal(track.artist, 'Singer');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('rejects redirects outside Kugou domains', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(null, { status: 302, headers: { location: 'http://127.0.0.1/private' } });
  try {
    const service = new KugouService({ sessionFile: 'unused.json' }, { warn() {} });
    service.cookies = { token: 'token', userid: '1' };
    await assert.rejects(() => service.resolve('https://m.kugou.com/share/unsafe'), /不受信任/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('builds timed lyric lines from Kugou lyric search results', async () => {
  const service = new KugouService({ sessionFile: 'unused.json' }, { warn() {} });
  service.request = async () => ({
    data: {
      lists: [{
        FileHash: 'TRACK_HASH',
        SongName: 'Test Song',
        SingerName: 'Test Artist',
        TimeLength: 120,
        Lyric: 'Test Song  第一句歌词  第二句歌词  第三句歌词'
      }]
    }
  });
  const lyrics = await service.lyrics({ hash: 'TRACK_HASH', title: 'Test Song', artist: 'Test Artist', duration: 120 });
  assert.deepEqual(lyrics.map((line) => line.text), ['Test Song', '第一句歌词', '第二句歌词', '第三句歌词']);
  assert.equal(lyrics[0].time < lyrics[1].time, true);
});
