import fs from 'node:fs';
import path from 'node:path';

const normalize = (value) => value.toLowerCase().replace(/\.[^.]+$/, '').replace(/[\s_\-—·]+/g, ' ').trim();
function walk(directory, extensions, output = []) {
  if (!fs.existsSync(directory)) return output;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(fullPath, extensions, output);
    else if (extensions.includes(path.extname(entry.name).toLowerCase())) output.push(fullPath);
  }
  return output;
}

export class MusicLibrary {
  constructor(config, logger) { this.config = config; this.logger = logger; this.tracks = []; this.scan(); }
  scan() {
    this.tracks = walk(this.config.directory, this.config.extensions).map((file) => ({
      id: Buffer.from(file).toString('base64url'), title: path.basename(file, path.extname(file)), file,
      format: path.extname(file).slice(1).toUpperCase()
    }));
    this.logger.info(`音乐库扫描完成：${this.tracks.length} 首`);
    return this.tracks;
  }
  search(query, limit = 8) {
    const needle = normalize(query);
    if (!needle) return [];
    return this.tracks.map((track) => {
      const title = normalize(track.title);
      const score = title === needle ? 100 : title.startsWith(needle) ? 80 : title.includes(needle) ? 60 : needle.split(' ').filter((word) => title.includes(word)).length * 10;
      return { ...track, score };
    }).filter((track) => track.score > 0).sort((a, b) => b.score - a.score || a.title.localeCompare(b.title, 'zh-CN')).slice(0, limit);
  }
}
