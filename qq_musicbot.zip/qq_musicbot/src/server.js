import path from 'node:path';
import fs from 'node:fs';
import http from 'node:http';
import express from 'express';
import { WebSocketServer } from 'ws';
import { config, projectRoot } from './config.js';
import { AppLogger } from './logger.js';
import { RuntimeStore } from './store.js';
import { MusicLibrary } from './music-library.js';
import { createCallBridge } from './call-bridge.js';
import { NapCatClient } from './napcat-client.js';
import { MusicBot } from './bot.js';
import { KugouService } from './kugou-service.js';
import { AdminAuth } from './admin-auth.js';
import { ShareRoomService } from './share-room-service.js';

const logger = new AppLogger();
const store = new RuntimeStore(path.join(projectRoot, 'data', 'runtime.json'));
const library = new MusicLibrary(config.music, logger);
const kugou = new KugouService(config.kugou, logger);
const bridge = createCallBridge(config.callBridge, logger);
const napcat = new NapCatClient(config.napcat, logger, store);
const shareRooms = new ShareRoomService(config.share, bridge, logger, projectRoot);
const bot = new MusicBot({ config: config.bot, napcat, bridge, library, kugou, logger, store, shareRooms });
const auth = new AdminAuth(path.join(projectRoot, 'data'));
const publicDirectory = path.join(projectRoot, 'public');
const app = express();
app.set('trust proxy', 'loopback');
app.use((_request, response, next) => {
  response.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self' ws: wss:; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('X-Frame-Options', 'DENY');
  response.setHeader('Referrer-Policy', 'no-referrer');
  response.setHeader('Permissions-Policy', 'camera=(), geolocation=(), payment=(), usb=()');
  next();
});
app.use(express.json({ limit: '1mb' }));
app.use((request, response, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(request.method)) return next();
  const origin = request.headers.origin;
  if (!origin) return next();
  try {
    if (new URL(origin).host === request.headers.host) return next();
  } catch {}
  response.status(403).json({ ok: false, message: '跨站请求已拒绝' });
});

app.use('/vendor', express.static(path.join(projectRoot, 'node_modules', 'three', 'build'), { index: false }));
app.get(['/login', '/login.html'], (request, response) => {
  if (auth.isAuthenticated(request)) return response.redirect('/');
  response.setHeader('Cache-Control', 'no-store');
  response.sendFile(path.join(publicDirectory, 'login.html'));
});
app.get('/login.css', (_request, response) => response.sendFile(path.join(publicDirectory, 'login.css')));
app.get('/login.js', (_request, response) => response.sendFile(path.join(publicDirectory, 'login.js')));
app.get('/api/auth/status', (request, response) => response.json({ authenticated: auth.isAuthenticated(request) }));
app.post('/api/auth/login', (request, response) => {
  const result = auth.login(request, request.body?.token);
  if (result.limited) {
    response.setHeader('Retry-After', String(result.retryAfter));
    return response.status(429).json({ ok: false, message: `尝试次数过多，请在 ${result.retryAfter} 秒后重试` });
  }
  if (!result.ok) return response.status(401).json({ ok: false, message: 'Token 无效' });
  response.setHeader('Set-Cookie', auth.cookie(request, result.sessionId, result.maxAge));
  response.json({ ok: true });
});
app.post('/api/auth/logout', (request, response) => {
  auth.logout(request);
  response.setHeader('Set-Cookie', auth.clearCookie(request));
  response.json({ ok: true });
});
app.use((request, response, next) => {
  if (auth.isAuthenticated(request)) return next();
  if (request.path.startsWith('/api/')) return response.status(401).json({ ok: false, message: '登录状态已失效' });
  response.redirect(`/login?next=${encodeURIComponent(request.originalUrl || '/')}`);
});
app.use(express.static(publicDirectory, { index: false }));

app.get('/api/overview', async (_request, response) => {
  let bridgeHealth = { ok: false, mode: bridge.mode };
  try { bridgeHealth = await bridge.health(); } catch (error) { bridgeHealth.reason = error.message; }
  store.update({ bridgeConnected: bridgeHealth.ok === true });
  response.json({
    state: store.snapshot(),
    config: { command: config.bot.command, bridgeMode: bridge.mode, musicDirectory: config.music.directory, napcatHttpUrl: config.napcat.httpUrl, napcatWsUrl: config.napcat.wsUrl },
    bridgeHealth, kugou: kugou.status(), libraryCount: library.tracks.length, logs: logger.entries.slice(0, 80)
  });
});
app.get('/api/library', (request, response) => {
  const query = String(request.query.q || '');
  response.json(query ? library.search(query, 30) : library.tracks.slice(0, 200));
});
app.post('/api/library/rescan', (_request, response) => response.json({ ok: true, count: library.scan().length }));
app.get('/api/kugou/status', (_request, response) => response.json(kugou.status()));
app.post('/api/kugou/qr', async (_request, response) => {
  try { response.json(await kugou.createQr()); }
  catch (error) { response.status(502).json({ ok: false, message: error.message }); }
});
app.get('/api/kugou/qr/:key/status', async (request, response) => {
  try { response.json(await kugou.checkQr(request.params.key)); }
  catch (error) { response.status(502).json({ ok: false, message: error.message }); }
});
app.get('/api/kugou/search', async (request, response) => {
  try { response.json(await kugou.search(String(request.query.q || ''), 20)); }
  catch (error) { response.status(502).json({ ok: false, message: error.message }); }
});
app.post('/api/kugou/logout', (_request, response) => { kugou.logout(); response.json({ ok: true }); });
app.post('/api/test-command', async (request, response) => {
  const groupId = String(request.body.groupId || '10001');
  const argument = String(request.body.query || '').trim();
  if (!argument) return response.status(400).json({ ok: false, message: '请输入音乐名' });
  const originalReply = bot.reply.bind(bot);
  bot.reply = async (_groupId, message) => logger.info(`[控制台模拟回复] ${message}`);
  await bot.execute({ groupId, userId: 'dashboard', argument });
  bot.reply = originalReply;
  response.json({ ok: true });
});
app.post('/api/mock-call', (request, response) => {
  if (bridge.mode !== 'mock') return response.status(400).json({ ok: false, message: '仅 mock 模式可用' });
  bridge.setActive(String(request.body.groupId || '10001'), request.body.active === true);
  response.json({ ok: true });
});
app.post('/api/stop', async (request, response) => {
  try {
    const groupId = String(request.body.groupId || store.state.current?.groupId || '');
    await bridge.stop(groupId);
    shareRooms.closeGroup(groupId, 'stopped');
    store.update({ current: null });
    response.json({ ok: true });
  }
  catch (error) { response.status(500).json({ ok: false, message: error.message }); }
});
app.get('/api/health', (_request, response) => response.json({ ok: true, time: new Date().toISOString() }));
app.get('/', (_request, response) => response.sendFile(path.join(publicDirectory, 'index.html')));
app.use((_request, response) => response.sendFile(path.join(publicDirectory, 'index.html')));

const server = http.createServer(app);
const wss = new WebSocketServer({
  server,
  path: '/live',
  verifyClient: ({ req }, done) => done(auth.isAuthenticated(req), 401, 'Unauthorized')
});
const broadcast = (type, data) => {
  const payload = JSON.stringify({ type, data });
  for (const client of wss.clients) if (client.readyState === 1) client.send(payload);
};
logger.on('entry', (entry) => broadcast('log', entry));
store.on('change', (state) => broadcast('state', state));
fs.mkdirSync(config.music.directory, { recursive: true });
server.listen(config.server.port, config.server.host, () => {
  logger.success(`控制台已启动：http://${config.server.host}:${config.server.port}`);
  if (auth.createdToken) process.stdout.write(`管理后台登录 Token 已生成：${auth.tokenFile}\n`);
  logger.info(`管理后台 Token 文件：${auth.tokenFile}`);
  logger.info(`群通话桥接模式：${bridge.mode}`);
  bridge.start?.();
  shareRooms.start().catch((error) => logger.error(`临时音乐房间启动失败：${error.message}`));
  kugou.start();
  napcat.connect();
});
const shutdown = () => { auth.close(); napcat.stop(); kugou.stop(); shareRooms.stop(); bridge.close?.(); server.close(() => process.exit(0)); };
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
