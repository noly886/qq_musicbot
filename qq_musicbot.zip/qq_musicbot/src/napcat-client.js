import { EventEmitter } from 'node:events';
import WebSocket from 'ws';

export class NapCatClient extends EventEmitter {
  constructor(config, logger, store) {
    super(); this.config = config; this.logger = logger; this.store = store;
    this.socket = null; this.reconnectTimer = null; this.stopped = false;
  }
  connect() {
    if (this.stopped) return;
    const headers = this.config.accessToken ? { authorization: `Bearer ${this.config.accessToken}` } : {};
    this.logger.info(`正在连接 NapCat WebSocket：${this.config.wsUrl}`);
    this.socket = new WebSocket(this.config.wsUrl, { headers });
    this.socket.on('open', () => { this.store.update({ napcatConnected: true }); this.logger.success('NapCat WebSocket 已连接'); });
    this.socket.on('message', (buffer) => {
      try { const event = JSON.parse(buffer.toString()); if (event.post_type) this.emit('event', event); }
      catch (error) { this.logger.warn('收到无法解析的 NapCat 消息', error.message); }
    });
    this.socket.on('close', () => this.scheduleReconnect());
    this.socket.on('error', (error) => this.logger.warn(`NapCat WebSocket 异常：${error.message}`));
  }
  scheduleReconnect() {
    this.store.update({ napcatConnected: false });
    if (this.stopped || this.reconnectTimer) return;
    this.logger.warn('NapCat 连接断开，5 秒后重连');
    this.reconnectTimer = setTimeout(() => { this.reconnectTimer = null; this.connect(); }, 5000);
  }
  async action(action, params = {}) {
    const response = await fetch(`${this.config.httpUrl.replace(/\/$/, '')}/${action}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...(this.config.accessToken ? { authorization: `Bearer ${this.config.accessToken}` } : {}) },
      body: JSON.stringify(params), signal: AbortSignal.timeout(10000)
    });
    if (!response.ok) throw new Error(`NapCat HTTP ${response.status}`);
    const result = await response.json();
    if (result.status === 'failed') throw new Error(result.message || result.wording || 'NapCat 动作执行失败');
    return result.data;
  }
  sendGroupMessage(groupId, message) { return this.action('send_group_msg', { group_id: Number(groupId), message }); }
  stop() { this.stopped = true; clearTimeout(this.reconnectTimer); this.socket?.close(); }
}
