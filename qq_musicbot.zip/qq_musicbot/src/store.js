import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';

const initialState = {
  startedAt: new Date().toISOString(), commands: 0, played: 0, rejected: 0, errors: 0,
  napcatConnected: false, bridgeConnected: false, current: null, recent: [],
  requestRankings: {},
  activity: Array.from({ length: 12 }, (_, index) => ({ label: `${String(index * 2).padStart(2, '0')}:00`, value: 0 }))
};

export class RuntimeStore extends EventEmitter {
  constructor(file) { super(); this.file = file; this.state = structuredClone(initialState); this.load(); }
  load() {
    try {
      if (fs.existsSync(this.file)) {
        const persisted = JSON.parse(fs.readFileSync(this.file, 'utf8'));
        this.state = { ...this.state, ...persisted, napcatConnected: false, bridgeConnected: false, current: null };
      }
    } catch {}
  }
  update(patch) { this.state = { ...this.state, ...patch }; this.persist(); this.emit('change', this.snapshot()); }
  increment(field) { this.update({ [field]: (this.state[field] || 0) + 1 }); }
  addMusicRequest({ groupId, userId, title }) {
    const groupKey = String(groupId);
    const displayTitle = String(title || '').trim().replace(/\s+/g, ' ');
    const normalizedTitle = displayTitle.toLocaleLowerCase('zh-CN');
    const current = this.state.requestRankings?.[groupKey] || { total: 0, entries: [] };
    const entries = current.entries.map((entry) => ({ ...entry }));
    const existing = entries.find((entry) => entry.key === normalizedTitle);
    const requestedAt = new Date().toISOString();
    if (existing) {
      existing.count += 1;
      existing.title = displayTitle;
      existing.lastRequestedAt = requestedAt;
      existing.lastUserId = String(userId);
    } else {
      entries.push({
        key: normalizedTitle,
        title: displayTitle,
        count: 1,
        firstRequestedAt: requestedAt,
        lastRequestedAt: requestedAt,
        lastUserId: String(userId)
      });
    }
    entries.sort((left, right) => right.count - left.count
      || left.firstRequestedAt.localeCompare(right.firstRequestedAt)
      || left.title.localeCompare(right.title, 'zh-CN'));
    const ranking = { total: current.total + 1, entries: entries.slice(0, 20) };
    this.update({ requestRankings: { ...this.state.requestRankings, [groupKey]: ranking } });
    return structuredClone(ranking);
  }
  addPlay(item) {
    const bucket = Math.floor(new Date().getHours() / 2);
    const activity = this.state.activity.map((point, index) => index === bucket ? { ...point, value: point.value + 1 } : point);
    this.update({ played: this.state.played + 1, current: item, activity, recent: [item, ...this.state.recent].slice(0, 20) });
  }
  persist() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    fs.writeFileSync(this.file, JSON.stringify({ ...this.state, napcatConnected: false, bridgeConnected: false, current: null }, null, 2));
  }
  snapshot() { return structuredClone(this.state); }
}
