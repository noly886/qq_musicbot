import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';

function safeName(value) {
  return value.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 120) || 'kugou-track';
}

function firstValue(object, keys) {
  for (const key of keys) if (object?.[key] !== undefined && object?.[key] !== null) return object[key];
  return '';
}

function normalizeSongText(value) {
  return String(value || '').toLowerCase().replace(/[\s_\-—·、，,。.()（）【】\[\]]+/g, '');
}

export function decodeEscapedText(value) {
  let output = String(value || '');
  for (let attempt = 0; attempt < 3 && /\\+u[0-9a-f]{4}|\\+x[0-9a-f]{2}/i.test(output); attempt += 1) {
    output = output
      .replace(/\\+u([0-9a-f]{4})/gi, (_match, code) => String.fromCharCode(Number.parseInt(code, 16)))
      .replace(/\\+x([0-9a-f]{2})/gi, (_match, code) => String.fromCharCode(Number.parseInt(code, 16)));
  }
  return output.replace(/\\\//g, '/');
}

function decodeHtml(value) {
  return decodeEscapedText(String(value || '')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#(\d+);/g, (_match, code) => String.fromCodePoint(Number(code))));
}

function isKugouHost(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/\.$/, '');
  return host === 'kugou.com' || host.endsWith('.kugou.com');
}

export function extractKugouUrl(value) {
  const matches = String(value || '').match(/https?:\/\/[^\s<>"'，。！？、；（）【】]+/gi) || [];
  for (const match of matches) {
    const candidate = match.replace(/[，。！？、；;）)\]}]+$/, '');
    try {
      const url = new URL(candidate);
      if (isKugouHost(url.hostname) && (!url.port || ['80', '443'].includes(url.port))) return url;
    } catch {}
  }
  return null;
}

export function isKugouInput(value) {
  return Boolean(extractKugouUrl(value));
}

function metaContent(html, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const patterns = [
    new RegExp(`<meta[^>]+(?:property|name)=["']${escaped}["'][^>]+content=["']([^"']+)["']`, 'i'),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${escaped}["']`, 'i')
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match) return decodeHtml(match[1]).trim();
  }
  return '';
}

function pageTitle(html) {
  const value = metaContent(html, 'og:title') || decodeHtml(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]);
  return String(value || '')
    .replace(/\s*[-_|]\s*酷狗音乐.*$/i, '')
    .replace(/\s*[-_|]\s*酷狗.*$/i, '')
    .replace(/^分享歌曲[:：]?\s*/i, '')
    .trim();
}

function pageValue(html, keys) {
  for (const key of keys) {
    const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = html.match(new RegExp(`["']${escaped}["']\\s*:\\s*["']([^"']+)["']`, 'i'));
    if (match?.[1]) return decodeHtml(match[1]).trim();
  }
  return '';
}

function cleanSongTitle(title, artist) {
  const value = decodeEscapedText(title).trim();
  const singer = decodeEscapedText(artist).trim();
  if (!singer) return value;
  return value.replace(new RegExp(`^${singer.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*[-—]\\s*`, 'i'), '').trim();
}

function trackScore(track, query) {
  const needle = normalizeSongText(query);
  const title = normalizeSongText(track.title);
  const artist = normalizeSongText(track.artist);
  const combined = `${artist}${title}`;
  let score = title === needle ? 200 : combined === needle ? 190 : title.startsWith(needle) ? 150 : title.includes(needle) ? 120 : combined.includes(needle) ? 100 : 0;
  const versionWords = /live|dj|cover|翻唱|现场|伴奏|纯音乐|加速|减速|remix|片段|版/i;
  if (!versionWords.test(query) && versionWords.test(track.title)) score -= 45;
  if (track.album) score += 5;
  return score;
}

function uniqueLyricLines(value) {
  const output = [];
  for (const line of decodeEscapedText(value).split(/[\r\n]+|\s{2,}/)) {
    const text = line.trim().replace(/^[-–—]\s*/, '');
    if (!text || /^作词|^作曲|^编曲|^制作人|^混音|^母带|^出品|^发行/.test(text)) continue;
    if (output.at(-1) !== text) output.push(text);
  }
  return output.slice(0, 80);
}

function timedLyricLines(lines, duration) {
  if (!lines.length) return [];
  const total = Math.max(Number(duration) || 180, lines.length * 3);
  const start = Math.min(8, total * 0.06);
  const interval = Math.max(2.8, (total - start - 5) / lines.length);
  return lines.map((text, index) => ({ time: Number((start + interval * index).toFixed(2)), text }));
}

export class KugouService {
  constructor(config, logger) {
    this.config = config;
    this.logger = logger;
    this.process = null;
    this.cookies = {};
    this.user = null;
    this.ready = false;
    this.loadSession();
  }

  loadSession() {
    try {
      if (fs.existsSync(this.config.sessionFile)) {
        const session = JSON.parse(fs.readFileSync(this.config.sessionFile, 'utf8'));
        this.cookies = session.cookies || {};
        this.user = session.user || null;
      }
    } catch (error) {
      this.logger.warn(`酷狗会话读取失败：${error.message}`);
    }
  }

  saveSession() {
    fs.mkdirSync(path.dirname(this.config.sessionFile), { recursive: true });
    fs.writeFileSync(this.config.sessionFile, JSON.stringify({ cookies: this.cookies, user: this.user }, null, 2));
  }

  cookieHeader() {
    return Object.entries(this.cookies).map(([key, value]) => `${key}=${value}`).join('; ');
  }

  captureCookies(response) {
    const values = typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [];
    for (const line of values) {
      const pair = line.split(';', 1)[0];
      const separator = pair.indexOf('=');
      if (separator > 0) this.cookies[pair.slice(0, separator)] = pair.slice(separator + 1);
    }
    if (values.length) this.saveSession();
  }

  async start() {
    if (!this.config.enabled) return false;
    try { await this.health(); this.ready = true; return true; } catch {}
    if (!fs.existsSync(path.join(this.config.serviceDirectory, 'app.js'))) {
      this.logger.error('酷狗适配服务源码不存在');
      return false;
    }
    this.process = spawn(process.execPath, ['app.js'], {
      cwd: this.config.serviceDirectory,
      env: { ...process.env, PORT: String(this.config.port), HOST: '127.0.0.1' },
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    this.process.stdout.on('data', (data) => this.logger.info(`[酷狗适配器] ${data.toString().trim()}`));
    this.process.stderr.on('data', (data) => this.logger.warn(`[酷狗适配器] ${data.toString().trim()}`));
    this.process.on('exit', () => { this.ready = false; this.process = null; });
    for (let attempt = 0; attempt < 20; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      try { await this.health(); this.ready = true; this.logger.success('酷狗音乐适配服务已启动'); return true; } catch {}
    }
    this.logger.error('酷狗音乐适配服务启动超时');
    return false;
  }

  async request(route, params = {}) {
    const url = new URL(route, this.config.baseUrl);
    for (const [key, value] of Object.entries(params)) if (value !== undefined && value !== '') url.searchParams.set(key, String(value));
    url.searchParams.set('timestamp', String(Date.now()));
    const response = await fetch(url, { headers: this.cookieHeader() ? { cookie: this.cookieHeader() } : {}, signal: AbortSignal.timeout(20000) });
    this.captureCookies(response);
    const body = await response.json();
    if (!response.ok) throw new Error(body?.msg || body?.message || `酷狗 API HTTP ${response.status}`);
    return body;
  }

  async health() {
    const response = await fetch(`${this.config.baseUrl}/`, { signal: AbortSignal.timeout(1500) });
    if (!response.ok) throw new Error('酷狗适配服务不可用');
    return true;
  }

  status() {
    return { ready: this.ready, loggedIn: Boolean(this.cookies.token && this.cookies.userid), user: this.user };
  }

  async createQr() {
    const keyResponse = await this.request('/login/qr/key');
    const key = keyResponse?.data?.qrcode || keyResponse?.data;
    if (!key) throw new Error('酷狗二维码 Key 获取失败');
    const qrResponse = await this.request('/login/qr/create', { key, qrimg: true });
    return { key, image: qrResponse?.data?.base64 || keyResponse?.data?.qrcode_img, url: qrResponse?.data?.url };
  }

  async checkQr(key) {
    const response = await this.request('/login/qr/check', { key });
    const data = response?.data || {};
    const status = Number(data.status ?? response.status ?? 1);
    if (status === 4) {
      if (data.token) this.cookies.token = data.token;
      if (data.userid) this.cookies.userid = String(data.userid);
      this.user = { id: String(data.userid || ''), nickname: data.nickname || data.username || '酷狗用户', avatar: data.pic || data.avatar || '' };
      this.saveSession();
      this.logger.success(`酷狗音乐登录成功：${this.user.nickname}`);
    }
    return { status, loggedIn: status === 4, user: this.user };
  }

  logout() {
    this.cookies = {};
    this.user = null;
    if (fs.existsSync(this.config.sessionFile)) fs.rmSync(this.config.sessionFile);
  }

  normalizeTracks(response) {
    const source = response?.data?.lists || response?.data?.info || response?.data?.songs || response?.data || [];
    const list = Array.isArray(source) ? source : [];
    return list.map((item) => {
      const artist = decodeEscapedText(firstValue(item, ['SingerName', 'singername', 'AuthorName', 'author_name']));
      const rawTitle = decodeEscapedText(firstValue(item, ['SongName', 'songname', 'AudioName', 'name', 'FileName']));
      const hashes = [...new Set([
        firstValue(item, ['HQFileHash']),
        firstValue(item, ['SQFileHash']),
        firstValue(item, ['FileHash', 'Hash', 'hash'])
      ].map(String).filter(Boolean))];
      return {
        id: String(firstValue(item, ['EMixSongID', 'MixSongID', 'album_audio_id', 'Audioid', 'ID'])),
        hash: hashes[0] || '',
        hashes,
        albumId: String(firstValue(item, ['AlbumID', 'album_id', 'AlbumId'])),
        albumAudioId: String(firstValue(item, ['album_audio_id', 'Audioid', 'ID'])),
        title: cleanSongTitle(rawTitle, artist),
        artist,
        album: String(firstValue(item, ['AlbumName', 'album_name'])),
        duration: Number(firstValue(item, ['Duration', 'duration']) || 0)
      };
    }).filter((track) => track.hash && track.title);
  }

  async search(query, limit = 10) {
    if (!this.status().loggedIn) throw new Error('请先在后台扫码登录酷狗音乐');
    const requestLimit = Math.max(limit, 20);
    return this.normalizeTracks(await this.request('/search', { keywords: query, pagesize: requestLimit, type: 'song' }))
      .map((track) => ({ ...track, matchScore: trackScore(track, query) }))
      .sort((left, right) => right.matchScore - left.matchScore)
      .slice(0, limit);
  }

  async lyrics(track) {
    try {
      const response = await this.request('/search', {
        keywords: track.title,
        pagesize: 30,
        type: 'lyric'
      });
      const source = Array.isArray(response?.data?.lists) ? response.data.lists : [];
      const exactHash = source.find((item) => String(firstValue(item, ['FileHash', 'Hash', 'hash'])).toUpperCase() === String(track.hash).toUpperCase());
      const normalizedTitle = normalizeSongText(track.title);
      const normalizedArtist = normalizeSongText(track.artist);
      const best = exactHash || source
        .map((item) => {
          const title = normalizeSongText(firstValue(item, ['SongName', 'songname', 'FileName']));
          const artist = normalizeSongText(firstValue(item, ['SingerName', 'singername']));
          const score = (title === normalizedTitle ? 100 : title.includes(normalizedTitle) ? 60 : 0)
            + (normalizedArtist && artist === normalizedArtist ? 50 : normalizedArtist && artist.includes(normalizedArtist) ? 25 : 0);
          return { item, score };
        })
        .sort((left, right) => right.score - left.score)[0]?.item;
      if (!best) return [];
      return timedLyricLines(uniqueLyricLines(best.FullLyric || best.Lyric || best.lyric), track.duration || firstValue(best, ['TimeLength', 'Duration']));
    } catch (error) {
      this.logger.warn(`酷狗歌词获取失败：${error.message}`);
      return [];
    }
  }

  async fetchKugouPage(input) {
    let current = extractKugouUrl(input);
    if (!current) throw new Error('未识别到有效的酷狗音乐链接');
    for (let attempt = 0; attempt < 6; attempt += 1) {
      const response = await fetch(current, {
        redirect: 'manual',
        headers: { 'user-agent': 'Mozilla/5.0 PulseOps/1.1' },
        signal: AbortSignal.timeout(15000)
      });
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get('location');
        if (!location) throw new Error('酷狗分享链接跳转地址无效');
        const next = new URL(location, current);
        if (!isKugouHost(next.hostname) || (next.port && !['80', '443'].includes(next.port))) throw new Error('酷狗分享链接跳转到了不受信任的地址');
        current = next;
        continue;
      }
      if (!response.ok) throw new Error(`酷狗分享页面访问失败：HTTP ${response.status}`);
      return { url: current, html: await response.text() };
    }
    throw new Error('酷狗分享链接跳转次数过多');
  }

  async resolveKugouLink(input) {
    if (!this.status().loggedIn) throw new Error('请先在后台扫码登录酷狗音乐');
    const { url, html } = await this.fetchKugouPage(input);
    const hash = url.searchParams.get('hash') || pageValue(html, ['hash', 'FileHash', 'fileHash']);
    const albumId = url.searchParams.get('album_id') || url.searchParams.get('albumId') || pageValue(html, ['album_id', 'AlbumID', 'albumId']);
    const albumAudioId = url.searchParams.get('album_audio_id') || url.searchParams.get('audio_id') || pageValue(html, ['album_audio_id', 'audio_id', 'Audioid']);
    const artist = decodeEscapedText(pageValue(html, ['author_name', 'singername', 'SingerName', 'singer_name']));
    const title = cleanSongTitle(pageValue(html, ['song_name', 'songName', 'SongName', 'audio_name']) || pageTitle(html), artist);
    if (hash) {
      let track = {
        id: albumAudioId || hash,
        hash,
        hashes: [hash],
        albumId,
        albumAudioId,
        title: title || '酷狗分享歌曲',
        artist,
        album: ''
      };
      if (title) {
        try {
          const matches = await this.search(title, 8);
          track = matches.find((item) => item.hash === hash || item.hashes?.includes(hash))
            || matches.find((item) => normalizeSongText(item.title) === normalizeSongText(title) && (!artist || normalizeSongText(item.artist).includes(normalizeSongText(artist))))
            || track;
        } catch {}
      }
      return this.download({ ...track, lyrics: await this.lyrics(track) });
    }
    if (!title) throw new Error('无法从酷狗分享链接识别歌曲信息');
    const [track] = await this.search(title, 1);
    return track ? this.download({ ...track, lyrics: await this.lyrics(track) }) : null;
  }

  findAudioUrl(response) {
    const data = response?.data || response;
    const candidates = [data?.url, data?.play_url, data?.playUrl, data?.backup_url, data?.urls, data?.url_list].flat(Infinity);
    for (const candidate of candidates) {
      if (typeof candidate === 'string' && /^https?:\/\//.test(candidate)) return candidate;
      if (candidate && typeof candidate === 'object') {
        const value = candidate.url || candidate.play_url;
        if (typeof value === 'string' && /^https?:\/\//.test(value)) return value;
      }
    }
    return '';
  }

  async download(track) {
    let audioUrl = '';
    let selectedHash = '';
    let selectedQuality = '';
    for (const hash of track.hashes?.length ? track.hashes : [track.hash]) {
      for (const quality of ['320', '128']) {
        try {
          const detail = await this.request('/song/url', { hash, album_id: track.albumId, album_audio_id: track.albumAudioId, quality });
          audioUrl = this.findAudioUrl(detail);
          if (audioUrl) {
            selectedHash = hash;
            selectedQuality = quality;
            break;
          }
        } catch (error) {
          this.logger.warn(`酷狗 ${quality}kbps 音质获取失败：${error.message}`);
        }
      }
      if (audioUrl) break;
    }
    if (!audioUrl) throw new Error('酷狗未返回可播放地址，歌曲可能需要 VIP 或版权受限');
    fs.mkdirSync(this.config.cacheDirectory, { recursive: true });
    const extension = path.extname(new URL(audioUrl).pathname) || '.mp3';
    const file = path.join(this.config.cacheDirectory, `${safeName(`${track.artist} - ${track.title}`)}-${selectedQuality}k-${selectedHash.slice(0, 8)}${extension}`);
    if (!fs.existsSync(file)) {
      const response = await fetch(audioUrl, { headers: this.cookieHeader() ? { cookie: this.cookieHeader() } : {}, signal: AbortSignal.timeout(120000) });
      if (!response.ok || !response.body) throw new Error(`歌曲下载失败：HTTP ${response.status}`);
      await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(file));
    }
    return {
      id: selectedHash,
      title: track.artist ? `${track.artist} - ${track.title}` : track.title,
      artist: track.artist || '',
      songTitle: track.title,
      album: track.album || '',
      duration: track.duration || 0,
      lyrics: track.lyrics || [],
      file,
      format: extension.slice(1).toUpperCase(),
      quality: `${selectedQuality}kbps`,
      source: 'kugou'
    };
  }

  async resolve(query) {
    if (isKugouInput(query)) return this.resolveKugouLink(query);
    const [track] = await this.search(query, 1);
    if (!track) return null;
    return this.download({ ...track, lyrics: await this.lyrics(track) });
  }

  stop() { this.process?.kill(); }
}
