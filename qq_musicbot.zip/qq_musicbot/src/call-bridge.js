class DisabledCallBridge {
  constructor(logger) { this.logger = logger; this.mode = 'disabled'; }
  async health() { return { ok: false, mode: this.mode, reason: 'NapCat 未提供群通话 API' }; }
  async hasActiveCall() { throw new Error('未配置群通话检测桥接器，NapCat 无法读取群电话状态'); }
  async join() { throw new Error('群通话桥接器未启用'); }
  async play() { throw new Error('群通话桥接器未启用'); }
  async stop() { return false; }
  async playback() { return { active: false, supported: false }; }
}

class MockCallBridge {
  constructor(logger) { this.logger = logger; this.mode = 'mock'; this.activeGroups = new Set(); }
  async health() { return { ok: true, mode: this.mode }; }
  async hasActiveCall(groupId) { return this.activeGroups.has(String(groupId)); }
  async join(groupId) { this.logger.info(`[演示] 已加入群 ${groupId} 的通话`); return true; }
  async play(groupId, track) { this.logger.success(`[演示] 正在群 ${groupId} 播放 ${track.title}`); return { ok: true, playbackId: `mock-${Date.now()}` }; }
  async stop(groupId) { this.logger.info(`[演示] 已停止群 ${groupId} 的播放`); return true; }
  async playback() { return { active: false, supported: false }; }
  setActive(groupId, active) { active ? this.activeGroups.add(String(groupId)) : this.activeGroups.delete(String(groupId)); }
}

class ExternalCallBridge {
  constructor(config, logger) { this.config = config; this.logger = logger; this.mode = 'external'; }
  async request(path, options = {}) {
    const response = await fetch(`${this.config.url.replace(/\/$/, '')}${path}`, {
      ...options,
      headers: {
        'content-type': 'application/json',
        ...(this.config.token ? { authorization: `Bearer ${this.config.token}` } : {}),
        ...options.headers
      },
      signal: AbortSignal.timeout(60000)
    });
    if (!response.ok) throw new Error(`通话桥接器返回 HTTP ${response.status}`);
    return response.json();
  }
  async health() { return this.request('/v1/health'); }
  async hasActiveCall(groupId) { return (await this.request(`/v1/groups/${encodeURIComponent(groupId)}/call`)).active === true; }
  async join(groupId) { return (await this.request(`/v1/groups/${encodeURIComponent(groupId)}/join`, { method: 'POST', body: '{}' })).ok === true; }
  async play(groupId, track, requestedBy) {
    return this.request(`/v1/groups/${encodeURIComponent(groupId)}/play`, {
      method: 'POST', body: JSON.stringify({ file: track.file, title: track.title, requestedBy })
    });
  }
  async stop(groupId) { return (await this.request(`/v1/groups/${encodeURIComponent(groupId)}/stop`, { method: 'POST', body: '{}' })).ok === true; }
  async playback() { return this.request('/v1/playback'); }
}

class WindowsCallBridge extends ExternalCallBridge {
  constructor(config, logger) {
    super(config, logger);
    this.mode = 'windows';
    this.process = null;
  }
  async start() {
    try { await this.health(); return true; } catch {}
    const { spawn } = await import('node:child_process');
    this.process = spawn(process.execPath, ['server.js'], {
      cwd: this.config.serviceDirectory,
      env: { ...process.env, PORT: '3211' },
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    this.process.stdout.on('data', (data) => this.logger.info(`[通话桥接器] ${data.toString().trim()}`));
    this.process.stderr.on('data', (data) => this.logger.warn(`[通话桥接器] ${data.toString().trim()}`));
    for (let attempt = 0; attempt < 40; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      try { const status = await this.health(); if (status.ok) return true; } catch {}
    }
    return false;
  }
  close() { this.process?.kill(); }
}

export function createCallBridge(config, logger) {
  if (config.mode === 'windows') return new WindowsCallBridge(config, logger);
  if (config.mode === 'external') return new ExternalCallBridge(config, logger);
  if (config.mode === 'mock') return new MockCallBridge(logger);
  return new DisabledCallBridge(logger);
}
