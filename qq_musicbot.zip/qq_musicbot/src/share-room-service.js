import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { decodeEscapedText } from './kugou-service.js';

const CLOSED_RETENTION = 2 * 60 * 1000;
const MIME_TYPES = {
  '.aac': 'audio/aac',
  '.flac': 'audio/flac',
  '.m4a': 'audio/mp4',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.wav': 'audio/wav'
};

function privateAddressScore(address, interfaceName) {
  if (address.startsWith('192.168.')) return 50;
  if (address.startsWith('10.')) return 40;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(address)) return 35;
  if (/wi-?fi|wlan|ethernet|以太网|无线/i.test(interfaceName)) return 20;
  return 10;
}

function findLanAddress() {
  const candidates = [];
  for (const [interfaceName, entries] of Object.entries(os.networkInterfaces())) {
    for (const entry of entries || []) {
      if (entry.family !== 'IPv4' || entry.internal || entry.address.startsWith('169.254.')) continue;
      candidates.push({ address: entry.address, score: privateAddressScore(entry.address, interfaceName) });
    }
  }
  candidates.sort((left, right) => right.score - left.score);
  return candidates[0]?.address || '127.0.0.1';
}

function maskGroup(groupId) {
  const value = String(groupId || '');
  return value.length <= 4 ? value : `***${value.slice(-4)}`;
}

export class ShareRoomService {
  constructor(config, bridge, logger, projectRoot) {
    this.config = config;
    this.bridge = bridge;
    this.logger = logger;
    this.projectRoot = projectRoot;
    this.sessions = new Map();
    this.server = null;
    this.monitorTimer = null;
  }

  baseUrl() {
    if (this.config.publicBaseUrl) return String(this.config.publicBaseUrl).replace(/\/$/, '');
    return `http://${findLanAddress()}:${this.config.port}`;
  }

  create({ groupId, userId, track, playback }) {
    if (!this.config.enabled || !track?.file || !fs.existsSync(track.file)) return null;
    this.closeGroup(groupId, 'replaced');
    const token = crypto.randomBytes(24).toString('base64url');
    const startedAt = playback?.startedAt || new Date().toISOString();
    const session = {
      token,
      groupId: String(groupId),
      userId: String(userId),
      playbackId: playback?.playbackId || '',
      title: decodeEscapedText(track.title || path.basename(track.file)),
      format: String(track.format || path.extname(track.file).slice(1)).toUpperCase(),
      lyrics: Array.isArray(track.lyrics) ? track.lyrics
        .map((line) => ({ time: Number(line.time) || 0, text: decodeEscapedText(line.text).trim() }))
        .filter((line) => line.text)
        .slice(0, 120) : [],
      file: path.resolve(track.file),
      startedAt,
      expiresAt: Date.now() + Number(this.config.maxLifetimeMs || 6 * 60 * 60 * 1000),
      status: 'playing',
      endedAt: null,
      reason: ''
    };
    this.sessions.set(token, session);
    return { token, url: `${this.baseUrl()}/listen/${token}`, session: this.publicSession(session) };
  }

  publicSession(session) {
    return {
      active: session.status === 'playing',
      title: decodeEscapedText(session.title),
      format: session.format,
      group: maskGroup(session.groupId),
      requestedBy: session.userId,
      startedAt: session.startedAt,
      endedAt: session.endedAt,
      reason: session.reason,
      lyrics: session.lyrics,
      mediaUrl: session.status === 'playing' ? `/media/${session.token}` : ''
    };
  }

  get(token) {
    return this.sessions.get(String(token || '')) || null;
  }

  close(token, reason = 'ended') {
    const session = this.get(token);
    if (!session || session.status !== 'playing') return false;
    session.status = 'ended';
    session.reason = reason;
    session.endedAt = new Date().toISOString();
    return true;
  }

  closeGroup(groupId, reason = 'ended') {
    let closed = false;
    for (const session of this.sessions.values()) {
      if (session.groupId === String(groupId) && session.status === 'playing') closed = this.close(session.token, reason) || closed;
    }
    return closed;
  }

  async monitor() {
    const now = Date.now();
    for (const [token, session] of this.sessions) {
      if (session.status !== 'playing' && Date.parse(session.endedAt) + CLOSED_RETENTION <= now) {
        this.sessions.delete(token);
      } else if (session.status === 'playing' && session.expiresAt <= now) {
        this.close(token, 'expired');
      }
    }
    if (![...this.sessions.values()].some((session) => session.status === 'playing')) return;
    try {
      const playback = await this.bridge.playback();
      if (playback?.supported === false) return;
      for (const session of this.sessions.values()) {
        if (session.status !== 'playing') continue;
        const samePlayback = !session.playbackId || session.playbackId === playback?.playbackId;
        const sameGroup = !playback?.groupId || session.groupId === String(playback.groupId);
        if (!playback?.active || !samePlayback || !sameGroup) this.close(session.token, 'ended');
      }
    } catch (error) {
      this.logger.warn(`音乐房间状态检测失败：${error.message}`);
    }
  }

  sendMedia(request, response, session) {
    if (session.status !== 'playing') return response.status(410).end();
    let stat;
    try { stat = fs.statSync(session.file); }
    catch { return response.status(404).end(); }
    const contentType = MIME_TYPES[path.extname(session.file).toLowerCase()] || 'application/octet-stream';
    response.setHeader('Accept-Ranges', 'bytes');
    response.setHeader('Cache-Control', 'private, no-store');
    response.setHeader('Content-Type', contentType);
    const range = request.headers.range;
    if (!range) {
      response.setHeader('Content-Length', stat.size);
      return fs.createReadStream(session.file).pipe(response);
    }
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match) return response.status(416).setHeader('Content-Range', `bytes */${stat.size}`).end();
    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2] ? Math.min(Number(match[2]), stat.size - 1) : stat.size - 1;
    if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || start > end || start >= stat.size) {
      return response.status(416).setHeader('Content-Range', `bytes */${stat.size}`).end();
    }
    response.status(206);
    response.setHeader('Content-Range', `bytes ${start}-${end}/${stat.size}`);
    response.setHeader('Content-Length', end - start + 1);
    return fs.createReadStream(session.file, { start, end }).pipe(response);
  }

  async start() {
    if (!this.config.enabled || this.server) return false;
    const app = express();
    app.disable('x-powered-by');
    app.use((_request, response, next) => {
      response.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
      response.setHeader('X-Content-Type-Options', 'nosniff');
      response.setHeader('X-Frame-Options', 'DENY');
      response.setHeader('Referrer-Policy', 'no-referrer');
      next();
    });
    app.get('/assets/share.css', (_request, response) => response.sendFile(path.join(this.projectRoot, 'public', 'share.css')));
    app.get('/assets/share.js', (_request, response) => response.sendFile(path.join(this.projectRoot, 'public', 'share.js')));
    app.get('/listen/:token', (request, response) => {
      if (!this.get(request.params.token)) return response.status(404).sendFile(path.join(this.projectRoot, 'public', 'share.html'));
      response.setHeader('Cache-Control', 'no-store');
      response.sendFile(path.join(this.projectRoot, 'public', 'share.html'));
    });
    app.get('/api/rooms/:token', (request, response) => {
      const session = this.get(request.params.token);
      if (!session) return response.status(404).json({ active: false, reason: 'not_found' });
      response.setHeader('Cache-Control', 'no-store');
      response.json(this.publicSession(session));
    });
    app.get('/media/:token', (request, response) => {
      const session = this.get(request.params.token);
      if (!session) return response.status(404).end();
      return this.sendMedia(request, response, session);
    });
    app.get('/health', (_request, response) => response.json({ ok: true, rooms: this.sessions.size }));
    app.use((_request, response) => response.status(404).sendFile(path.join(this.projectRoot, 'public', 'share.html')));
    this.server = http.createServer(app);
    await new Promise((resolve, reject) => {
      this.server.once('error', reject);
      this.server.listen(this.config.port, this.config.host, resolve);
    });
    this.monitorTimer = setInterval(() => this.monitor(), 1000);
    this.monitorTimer.unref?.();
    this.logger.success(`临时音乐房间已启动：${this.baseUrl()}`);
    return true;
  }

  async stop() {
    clearInterval(this.monitorTimer);
    this.monitorTimer = null;
    if (!this.server) return;
    const server = this.server;
    this.server = null;
    await new Promise((resolve) => server.close(resolve));
  }
}
