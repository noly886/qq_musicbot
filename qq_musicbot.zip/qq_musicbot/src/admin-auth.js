import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const SESSION_COOKIE = 'pulseops_session';
const SESSION_DURATION = 12 * 60 * 60 * 1000;
const FAILURE_WINDOW = 15 * 60 * 1000;
const MAX_FAILURES = 5;

function parseCookies(header = '') {
  const cookies = {};
  for (const part of header.split(';')) {
    const separator = part.indexOf('=');
    if (separator < 1) continue;
    const key = part.slice(0, separator).trim();
    const rawValue = part.slice(separator + 1).trim();
    try { cookies[key] = decodeURIComponent(rawValue); }
    catch { cookies[key] = rawValue; }
  }
  return cookies;
}

function safeEqual(left, right) {
  const leftBuffer = Buffer.from(String(left || ''), 'utf8');
  const rightBuffer = Buffer.from(String(right || ''), 'utf8');
  return leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer);
}

export class AdminAuth {
  constructor(dataDirectory) {
    this.dataDirectory = dataDirectory;
    this.tokenFile = path.join(dataDirectory, 'admin-token.json');
    this.sessions = new Map();
    this.failures = new Map();
    this.createdToken = false;
    fs.mkdirSync(dataDirectory, { recursive: true });
    this.token = this.loadToken();
    this.cleanupTimer = setInterval(() => this.cleanup(), 10 * 60 * 1000);
    this.cleanupTimer.unref?.();
  }

  loadToken() {
    if (fs.existsSync(this.tokenFile)) {
      const saved = JSON.parse(fs.readFileSync(this.tokenFile, 'utf8'));
      if (typeof saved.token !== 'string' || saved.token.length < 32) throw new Error('管理后台 Token 文件无效');
      return saved.token;
    }
    const token = crypto.randomBytes(32).toString('base64url');
    fs.writeFileSync(this.tokenFile, JSON.stringify({ token, createdAt: new Date().toISOString() }, null, 2), { mode: 0o600 });
    try { fs.chmodSync(this.tokenFile, 0o600); } catch {}
    this.createdToken = true;
    return token;
  }

  clientKey(request) {
    return request.ip || request.socket?.remoteAddress || 'unknown';
  }

  checkRateLimit(request) {
    const key = this.clientKey(request);
    const entry = this.failures.get(key);
    if (!entry) return { allowed: true, key };
    if (Date.now() - entry.startedAt >= FAILURE_WINDOW) {
      this.failures.delete(key);
      return { allowed: true, key };
    }
    if (entry.count < MAX_FAILURES) return { allowed: true, key };
    return { allowed: false, key, retryAfter: Math.ceil((FAILURE_WINDOW - (Date.now() - entry.startedAt)) / 1000) };
  }

  recordFailure(key) {
    const current = this.failures.get(key);
    if (!current || Date.now() - current.startedAt >= FAILURE_WINDOW) {
      this.failures.set(key, { count: 1, startedAt: Date.now() });
      return;
    }
    current.count += 1;
  }

  login(request, candidate) {
    const limit = this.checkRateLimit(request);
    if (!limit.allowed) return { ok: false, limited: true, retryAfter: limit.retryAfter };
    if (!safeEqual(candidate, this.token)) {
      this.recordFailure(limit.key);
      return { ok: false, limited: false };
    }
    this.failures.delete(limit.key);
    const sessionId = crypto.randomBytes(32).toString('base64url');
    this.sessions.set(sessionId, {
      createdAt: Date.now(),
      expiresAt: Date.now() + SESSION_DURATION,
      userAgent: String(request.headers['user-agent'] || '').slice(0, 300)
    });
    return { ok: true, sessionId, maxAge: Math.floor(SESSION_DURATION / 1000) };
  }

  sessionId(request) {
    return parseCookies(request.headers.cookie)[SESSION_COOKIE] || '';
  }

  session(request) {
    const sessionId = this.sessionId(request);
    if (!sessionId) return null;
    const session = this.sessions.get(sessionId);
    if (!session || session.expiresAt <= Date.now()) {
      this.sessions.delete(sessionId);
      return null;
    }
    return { id: sessionId, ...session };
  }

  isAuthenticated(request) {
    return Boolean(this.session(request));
  }

  cookie(request, sessionId, maxAge) {
    const secure = request.secure || String(request.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https';
    return [
      `${SESSION_COOKIE}=${encodeURIComponent(sessionId)}`,
      'Path=/',
      'HttpOnly',
      'SameSite=Strict',
      `Max-Age=${maxAge}`,
      secure ? 'Secure' : ''
    ].filter(Boolean).join('; ');
  }

  clearCookie(request) {
    return this.cookie(request, '', 0);
  }

  logout(request) {
    const sessionId = this.sessionId(request);
    if (sessionId) this.sessions.delete(sessionId);
  }

  cleanup() {
    const now = Date.now();
    for (const [sessionId, session] of this.sessions) if (session.expiresAt <= now) this.sessions.delete(sessionId);
    for (const [key, failure] of this.failures) if (now - failure.startedAt >= FAILURE_WINDOW) this.failures.delete(key);
  }

  close() {
    clearInterval(this.cleanupTimer);
    this.sessions.clear();
  }
}
