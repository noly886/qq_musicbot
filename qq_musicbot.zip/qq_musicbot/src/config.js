import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const defaults = {
  server: { host: '127.0.0.1', port: 3210 },
  napcat: { httpUrl: 'http://127.0.0.1:3000', wsUrl: 'ws://127.0.0.1:3001', accessToken: '' },
  bot: { command: '/music', allowedGroups: [], adminUsers: [] },
  share: { enabled: true, host: '0.0.0.0', port: 3213, publicBaseUrl: '', maxLifetimeMs: 6 * 60 * 60 * 1000 },
  music: { directory: './music', extensions: ['.mp3', '.flac', '.wav', '.m4a', '.ogg', '.aac'] },
  kugou: {
    enabled: true,
    baseUrl: 'http://127.0.0.1:3212',
    port: 3212,
    serviceDirectory: './services/KuGouMusicApi-main',
    sessionFile: './data/kugou-session.json',
    cacheDirectory: './music/kugou-cache'
  },
  callBridge: { mode: 'disabled', url: 'http://127.0.0.1:3211', token: '', serviceDirectory: './services/qq-call-bridge' }
};

function merge(base, override) {
  const output = structuredClone(base);
  for (const [key, value] of Object.entries(override ?? {})) {
    output[key] = value && typeof value === 'object' && !Array.isArray(value) ? merge(output[key] ?? {}, value) : value;
  }
  return output;
}

const configPath = path.join(projectRoot, 'config.json');
const fileConfig = fs.existsSync(configPath) ? JSON.parse(fs.readFileSync(configPath, 'utf8')) : {};
const config = merge(defaults, fileConfig);
config.server.port = Number(process.env.PORT || config.server.port);
config.napcat.httpUrl = process.env.NAPCAT_HTTP_URL || config.napcat.httpUrl;
config.napcat.wsUrl = process.env.NAPCAT_WS_URL || config.napcat.wsUrl;
config.napcat.accessToken = process.env.NAPCAT_ACCESS_TOKEN || config.napcat.accessToken;
config.callBridge.mode = process.env.CALL_BRIDGE_MODE || config.callBridge.mode;
config.callBridge.url = process.env.CALL_BRIDGE_URL || config.callBridge.url;
config.callBridge.token = process.env.CALL_BRIDGE_TOKEN || config.callBridge.token;
config.share.enabled = process.env.SHARE_ENABLED ? process.env.SHARE_ENABLED !== 'false' : config.share.enabled;
config.share.host = process.env.SHARE_HOST || config.share.host;
config.share.port = Number(process.env.SHARE_PORT || config.share.port);
config.share.publicBaseUrl = process.env.SHARE_PUBLIC_BASE_URL || config.share.publicBaseUrl;
config.music.directory = path.resolve(projectRoot, process.env.MUSIC_DIRECTORY || config.music.directory);
config.kugou.serviceDirectory = path.resolve(projectRoot, config.kugou.serviceDirectory);
config.kugou.sessionFile = path.resolve(projectRoot, config.kugou.sessionFile);
config.kugou.cacheDirectory = path.resolve(projectRoot, config.kugou.cacheDirectory);
config.callBridge.serviceDirectory = path.resolve(projectRoot, config.callBridge.serviceDirectory);

export { config, configPath, projectRoot };
