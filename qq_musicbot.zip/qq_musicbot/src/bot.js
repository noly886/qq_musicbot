import { isKugouInput } from './kugou-service.js';

function getText(event) {
  if (typeof event.raw_message === 'string') return event.raw_message.trim();
  if (!Array.isArray(event.message)) return '';
  return event.message.filter((segment) => segment.type === 'text').map((segment) => segment.data?.text || '').join('').trim();
}

export function formatRequestRanking(ranking, limit = 5) {
  const medals = ['🥇', '🥈', '🥉'];
  const rows = ranking.entries.slice(0, limit).map((entry, index) => {
    const marker = medals[index] || `${index + 1}.`;
    return `${marker} ${entry.title} · ${entry.count} 次`;
  });
  return `🏆 本群点歌排行榜（累计 ${ranking.total} 次）\n${rows.join('\n')}`;
}

export class MusicBot {
  constructor({ config, napcat, bridge, library, kugou, logger, store, shareRooms = null, subscribe = true }) {
    this.config = config; this.napcat = napcat; this.bridge = bridge; this.library = library; this.kugou = kugou; this.logger = logger; this.store = store; this.shareRooms = shareRooms;
    this.groupLocks = new Set();
    if (subscribe) this.napcat.on('event', (event) => this.handleEvent(event));
  }
  async reply(groupId, message) {
    try { await this.napcat.sendGroupMessage(groupId, message); }
    catch (error) { this.store.increment('errors'); this.logger.error(`群消息发送失败：${error.message}`); }
  }
  async handleEvent(event) {
    if (event.post_type !== 'message' || event.message_type !== 'group') return;
    const text = getText(event);
    const prefix = this.config.command;
    if (!(text === prefix || text.startsWith(`${prefix} `))) return;
    const groupId = String(event.group_id);
    const userId = String(event.user_id);
    if (this.config.allowedGroups.length && !this.config.allowedGroups.map(String).includes(groupId)) return;
    const argument = text.slice(prefix.length).trim();
    this.store.increment('commands');
    this.logger.info(`收到点歌指令：${argument || '(空)'}`, { groupId, userId });
    await this.execute({ groupId, userId, argument });
  }
  async execute({ groupId, userId, argument }) {
    if (!argument || ['help', '帮助'].includes(argument)) {
      return this.reply(groupId, '🎵 使用方法：/music 音乐名\n酷狗直链：/music 酷狗分享链接\n停止播放：/music stop\n查看状态：/music status');
    }
    if (['status', '状态'].includes(argument)) {
      const current = this.store.state.current;
      return this.reply(groupId, current && current.groupId === groupId ? `🎧 当前播放：${current.title}` : '当前没有正在播放的音乐。');
    }
    if (['stop', '停止'].includes(argument)) {
      try {
        await this.bridge.stop(groupId);
        this.shareRooms?.closeGroup(groupId, 'stopped');
        if (this.store.state.current?.groupId === groupId) this.store.update({ current: null });
        return this.reply(groupId, '⏹ 已停止播放。');
      } catch (error) { return this.reply(groupId, `停止失败：${error.message}`); }
    }
    const ranking = this.store.addMusicRequest({ groupId, userId, title: argument });
    if (ranking.total >= 2) await this.reply(groupId, formatRequestRanking(ranking));
    if (this.groupLocks.has(groupId)) return this.reply(groupId, '正在处理上一条点歌请求，请稍候。');
    this.groupLocks.add(groupId);
    try {
      let active = false;
      try { active = await this.bridge.hasActiveCall(groupId); }
      catch (error) {
        this.store.increment('errors');
        this.logger.error(`检测群通话失败：${error.message}`, { groupId });
        return this.reply(groupId, `无法检测群电话：${error.message}`);
      }
      if (!active) {
        this.store.increment('rejected');
        return this.reply(groupId, '群聊内没有电话，无法播放音乐。');
      }
      const localMatches = this.library.search(argument, 8);
      let track = localMatches.find((item) => !item.file.includes('kugou-cache'));
      if (!track && this.kugou?.status().loggedIn) {
        const directLink = isKugouInput(argument);
        await this.reply(groupId, directLink ? '🔗 正在解析酷狗音乐链接并获取音频…' : `🔎 本地没有找到「${argument}」，正在从酷狗音乐获取…`);
        track = await this.kugou.resolve(argument);
        if (track) this.library.scan();
      }
      if (!track) [track] = localMatches;
      if (!track) {
        const hint = this.kugou?.status().loggedIn ? '酷狗音乐也没有找到该歌曲。' : '请先在管理后台扫码登录酷狗音乐。';
        return this.reply(groupId, `未找到「${argument}」。${hint}`);
      }
      await this.bridge.join(groupId);
      const playback = await this.bridge.play(groupId, track, userId);
      const item = { id: `${Date.now()}`, title: track.title, format: track.format, groupId, userId, startedAt: new Date().toISOString() };
      this.store.addPlay(item);
      const room = this.shareRooms?.create({ groupId, userId, track, playback });
      const roomMessage = room ? `\n🌐 临时音乐房间：${room.url}\n歌曲结束后链接将自动关闭。` : '';
      await this.reply(groupId, `▶ 已加入群电话，正在播放：${track.title}${roomMessage}`);
    } catch (error) {
      this.store.increment('errors');
      this.logger.error(`播放失败：${error.message}`, { groupId, userId });
      await this.reply(groupId, `播放失败：${error.message}`);
    } finally { this.groupLocks.delete(groupId); }
  }
}
