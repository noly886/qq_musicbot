import { EventEmitter } from 'node:events';

export class AppLogger extends EventEmitter {
  constructor(limit = 300) { super(); this.limit = limit; this.entries = []; }
  write(level, message, details = null) {
    const entry = { id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, time: new Date().toISOString(), level, message, details };
    this.entries.unshift(entry);
    this.entries = this.entries.slice(0, this.limit);
    console[level === 'error' ? 'error' : 'log'](`[${entry.time}] [${level.toUpperCase()}] ${message}`);
    this.emit('entry', entry);
    return entry;
  }
  info(message, details) { return this.write('info', message, details); }
  success(message, details) { return this.write('success', message, details); }
  warn(message, details) { return this.write('warn', message, details); }
  error(message, details) { return this.write('error', message, details); }
}
