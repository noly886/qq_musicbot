PulseOps 环境一键配置器
========================

直接双击“PulseOps-Environment-Setup.exe”，同意管理员权限提示，然后点击“开始一键配置”。

自动完成：
1. 通过 Windows Package Manager 安装/更新 QQ、Node.js LTS、Python 3.14、VoiceMeeter Banana。
2. 从 NapCat 官方 GitHub Release 下载最新 NapCat.Framework.zip 并部署到项目目录。
3. 安装主项目、酷狗服务的 npm 依赖。
4. 安装 pywinauto、Pillow、pywin32。
5. 预下载 Tesseract 中文和英文 OCR 模型。
6. 根据 config.example.json 生成本地 config.json。
7. 创建 PulseOps 和 NapCat 桌面启动快捷方式。

注意：
- 安装过程需要联网。
- VoiceMeeter 虚拟声卡驱动通常要重启 Windows 后生效。
- QQ 登录、NapCat Token、允许的群号和管理员 QQ 无法安全自动猜测，需要安装完成后自行填写 config.json。
- 安装日志保存在配置器同目录的“安装日志.txt”。
