using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

[assembly: AssemblyTitle("PulseOps Environment Setup")]
[assembly: AssemblyDescription("One-click environment installer for PulseOps QQ music bot")]
[assembly: AssemblyProduct("PulseOps Environment Setup")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace PulseOpsEnvironmentSetup
{
    internal sealed class SetupOptions
    {
        public string ProjectPath;
        public bool InstallQQ;
        public bool InstallNode;
        public bool InstallPython;
        public bool InstallVoiceMeeter;
        public bool InstallNapCat;
        public bool InstallDependencies;
        public bool WarmOcr;
        public bool CreateShortcuts;
    }

    internal sealed class MainForm : Form
    {
        private readonly TextBox projectPathBox = new TextBox();
        private readonly Button browseButton = new Button();
        private readonly Button installButton = new Button();
        private readonly Button openProjectButton = new Button();
        private readonly ProgressBar progressBar = new ProgressBar();
        private readonly Label statusLabel = new Label();
        private readonly RichTextBox logBox = new RichTextBox();
        private readonly List<CheckBox> optionBoxes = new List<CheckBox>();
        private readonly string logFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "安装日志.txt");

        public MainForm()
        {
            Text = "PulseOps 环境一键配置器";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(840, 690);
            Size = new Size(920, 760);
            BackColor = Color.FromArgb(245, 247, 252);
            Font = new Font("Microsoft YaHei UI", 9F);
            Icon = SystemIcons.Shield;

            BuildInterface();
            projectPathBox.Text = @"C:\Users\Administrator\Desktop\qq_musicbot";
            Log("配置器已启动。安装过程需要联网，并可能要求重启 Windows。", Color.DimGray);
        }

        private void BuildInterface()
        {
            var header = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = Color.FromArgb(33, 45, 75) };
            var title = new Label
            {
                Text = "PulseOps 环境一键配置器",
                ForeColor = Color.White,
                Font = new Font("Microsoft YaHei UI", 20F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(24, 14)
            };
            var subtitle = new Label
            {
                Text = "自动安装 QQ、Node.js、Python、VoiceMeeter、NapCat 和项目依赖",
                ForeColor = Color.FromArgb(198, 208, 231),
                AutoSize = true,
                Location = new Point(28, 56)
            };
            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            Controls.Add(header);

            var body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24, 18, 24, 18), AutoScroll = true };
            Controls.Add(body);
            header.BringToFront();

            var projectLabel = new Label { Text = "项目目录", AutoSize = true, Font = new Font(Font, FontStyle.Bold), Location = new Point(24, 20) };
            projectPathBox.SetBounds(24, 44, 730, 30);
            projectPathBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            browseButton.Text = "浏览...";
            browseButton.SetBounds(764, 42, 92, 32);
            browseButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            browseButton.Click += BrowseProject;
            body.Controls.Add(projectLabel);
            body.Controls.Add(projectPathBox);
            body.Controls.Add(browseButton);

            var optionsLabel = new Label { Text = "安装项目", AutoSize = true, Font = new Font(Font, FontStyle.Bold), Location = new Point(24, 92) };
            body.Controls.Add(optionsLabel);

            var optionsPanel = new TableLayoutPanel
            {
                Location = new Point(24, 118),
                Size = new Size(832, 132),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                ColumnCount = 2,
                RowCount = 4,
                BackColor = Color.White,
                Padding = new Padding(12)
            };
            optionsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            optionsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            AddOption(optionsPanel, "安装/更新 Windows QQ", true, 0, 0);
            AddOption(optionsPanel, "安装 Node.js LTS", true, 1, 0);
            AddOption(optionsPanel, "安装 Python 3.14", true, 0, 1);
            AddOption(optionsPanel, "安装 VoiceMeeter Banana 虚拟声卡", true, 1, 1);
            AddOption(optionsPanel, "部署最新 NapCat Framework", true, 0, 2);
            AddOption(optionsPanel, "安装 npm 与 Python 依赖", true, 1, 2);
            AddOption(optionsPanel, "预下载 OCR 中文/英文模型", true, 0, 3);
            AddOption(optionsPanel, "生成桌面启动快捷方式", true, 1, 3);
            body.Controls.Add(optionsPanel);

            installButton.Text = "开始一键配置";
            installButton.Font = new Font(Font, FontStyle.Bold);
            installButton.BackColor = Color.FromArgb(48, 104, 218);
            installButton.ForeColor = Color.White;
            installButton.FlatStyle = FlatStyle.Flat;
            installButton.FlatAppearance.BorderSize = 0;
            installButton.SetBounds(24, 266, 180, 42);
            installButton.Click += StartInstallation;
            body.Controls.Add(installButton);

            openProjectButton.Text = "打开项目目录";
            openProjectButton.SetBounds(214, 266, 130, 42);
            openProjectButton.Click += delegate
            {
                if (Directory.Exists(projectPathBox.Text.Trim())) Process.Start("explorer.exe", projectPathBox.Text.Trim());
            };
            body.Controls.Add(openProjectButton);

            statusLabel.Text = "等待开始";
            statusLabel.AutoSize = true;
            statusLabel.Location = new Point(24, 324);
            body.Controls.Add(statusLabel);

            progressBar.SetBounds(24, 349, 832, 18);
            progressBar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            body.Controls.Add(progressBar);

            logBox.SetBounds(24, 385, 832, 235);
            logBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            logBox.ReadOnly = true;
            logBox.BackColor = Color.FromArgb(20, 25, 35);
            logBox.ForeColor = Color.Gainsboro;
            logBox.Font = new Font("Consolas", 9F);
            logBox.BorderStyle = BorderStyle.None;
            body.Controls.Add(logBox);

            var notice = new Label
            {
                Text = "说明：VoiceMeeter 驱动安装后通常需要重启。QQ 登录、NapCat Token 和群号属于个人信息，配置器不会自动填写。",
                ForeColor = Color.FromArgb(120, 75, 20),
                AutoSize = false,
                Size = new Size(832, 42),
                Location = new Point(24, 628),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            body.Controls.Add(notice);
        }

        private void AddOption(TableLayoutPanel panel, string text, bool enabled, int column, int row)
        {
            var checkBox = new CheckBox { Text = text, Checked = enabled, AutoSize = true, Margin = new Padding(4, 3, 4, 3) };
            optionBoxes.Add(checkBox);
            panel.Controls.Add(checkBox, column, row);
        }

        private void BrowseProject(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                dialog.Description = "选择 qq_musicbot 项目目录";
                dialog.SelectedPath = projectPathBox.Text.Trim();
                if (dialog.ShowDialog(this) == DialogResult.OK) projectPathBox.Text = dialog.SelectedPath;
            }
        }

        private async void StartInstallation(object sender, EventArgs e)
        {
            var projectPath = Path.GetFullPath(Environment.ExpandEnvironmentVariables(projectPathBox.Text.Trim()));
            if (!File.Exists(Path.Combine(projectPath, "package.json")) || !File.Exists(Path.Combine(projectPath, "config.example.json")))
            {
                MessageBox.Show(this, "所选目录不是有效的 qq_musicbot 项目。", "目录错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var options = new SetupOptions
            {
                ProjectPath = projectPath,
                InstallQQ = optionBoxes[0].Checked,
                InstallNode = optionBoxes[1].Checked,
                InstallPython = optionBoxes[2].Checked,
                InstallVoiceMeeter = optionBoxes[3].Checked,
                InstallNapCat = optionBoxes[4].Checked,
                InstallDependencies = optionBoxes[5].Checked,
                WarmOcr = optionBoxes[6].Checked,
                CreateShortcuts = optionBoxes[7].Checked
            };

            SetRunning(true);
            try
            {
                await Task.Run(delegate { InstallAll(options); });
                SetStatus("配置完成", 100);
                Log("全部选定步骤已执行完成。", Color.LightGreen);
                var message = "环境配置完成。\n\n下一步：打开项目中的 config.json，填写 NapCat Token、允许的群号和管理员 QQ。";
                if (options.InstallVoiceMeeter) message += "\n\nVoiceMeeter 驱动需要重启 Windows 后完全生效。";
                MessageBox.Show(this, message, "配置完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                SetStatus("配置未完全完成", progressBar.Value);
                Log("错误：" + ex.Message, Color.Salmon);
                MessageBox.Show(this, "配置过程中发生错误，详细信息已写入安装日志。\n\n" + ex.Message, "配置失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetRunning(false);
            }
        }

        private void InstallAll(SetupOptions options)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var steps = new List<Action>();
            if (options.InstallQQ) steps.Add(delegate { InstallWinget("Tencent.QQ.NT", "Windows QQ"); });
            if (options.InstallNode) steps.Add(delegate { InstallWinget("OpenJS.NodeJS.LTS", "Node.js LTS"); });
            if (options.InstallPython) steps.Add(delegate { InstallWinget("Python.Python.3.14", "Python 3.14"); });
            if (options.InstallVoiceMeeter) steps.Add(delegate { InstallWinget("VB-Audio.Voicemeeter.Banana", "VoiceMeeter Banana 虚拟声卡"); });
            if (options.InstallNapCat) steps.Add(delegate { InstallNapCat(options.ProjectPath); });
            if (options.InstallDependencies) steps.Add(delegate { InstallDependencies(options.ProjectPath); });
            if (options.WarmOcr) steps.Add(delegate { WarmOcr(options.ProjectPath); });
            steps.Add(delegate { PrepareProject(options.ProjectPath); });
            if (options.CreateShortcuts) steps.Add(delegate { CreateShortcuts(options.ProjectPath); });

            for (var index = 0; index < steps.Count; index++)
            {
                var percent = (int)Math.Round(index * 100.0 / steps.Count);
                SetStatus("正在执行第 " + (index + 1) + " / " + steps.Count + " 步", percent);
                steps[index]();
            }
        }

        private void InstallWinget(string packageId, string displayName)
        {
            Log("安装/更新 " + displayName + " ...", Color.LightSkyBlue);
            var args = "install --id " + packageId + " --exact --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity";
            var exitCode = RunProcess("winget.exe", args, null, true);
            if (exitCode != 0 && exitCode != 3010) throw new InvalidOperationException(displayName + " 安装失败，退出码：" + exitCode);
            RefreshPath();
            Log(displayName + " 已就绪。", Color.LightGreen);
        }

        private void InstallNapCat(string projectPath)
        {
            Log("查询 NapCat 官方最新版本 ...", Color.LightSkyBlue);
            string downloadUrl = null;
            string tag = null;
            using (var client = CreateWebClient())
            {
                var json = client.DownloadString("https://api.github.com/repos/NapNeko/NapCatQQ/releases/latest");
                var release = new JavaScriptSerializer().DeserializeObject(json) as Dictionary<string, object>;
                if (release == null) throw new InvalidOperationException("无法解析 NapCat Release 信息。");
                tag = Convert.ToString(release["tag_name"]);
                var assets = release["assets"] as IEnumerable;
                if (assets != null)
                {
                    foreach (var item in assets)
                    {
                        var asset = item as Dictionary<string, object>;
                        if (asset == null) continue;
                        if (string.Equals(Convert.ToString(asset["name"]), "NapCat.Framework.zip", StringComparison.OrdinalIgnoreCase))
                        {
                            downloadUrl = Convert.ToString(asset["browser_download_url"]);
                            break;
                        }
                    }
                }
            }
            if (string.IsNullOrWhiteSpace(downloadUrl)) throw new InvalidOperationException("最新 NapCat Release 中没有 NapCat.Framework.zip。");

            var tempZip = Path.Combine(Path.GetTempPath(), "NapCat.Framework-" + Guid.NewGuid().ToString("N") + ".zip");
            try
            {
                Log("下载 NapCat " + tag + " ...", Color.LightSkyBlue);
                using (var client = CreateWebClient()) client.DownloadFile(downloadUrl, tempZip);
                var target = Path.Combine(projectPath, "NapCat.Framework");
                Directory.CreateDirectory(target);
                ExtractZipOverwrite(tempZip, target);
                Log("NapCat " + tag + " 已部署到项目目录。", Color.LightGreen);
            }
            finally
            {
                if (File.Exists(tempZip)) File.Delete(tempZip);
            }
        }

        private void InstallDependencies(string projectPath)
        {
            RefreshPath();
            Log("安装项目 npm 依赖 ...", Color.LightSkyBlue);
            RunRequired("cmd.exe", "/d /s /c \"npm.cmd install --no-audit --no-fund\"", projectPath, "主项目 npm 依赖");
            var kugou = Path.Combine(projectPath, "services", "KuGouMusicApi-main");
            RunRequired("cmd.exe", "/d /s /c \"npm.cmd install --omit=dev --no-audit --no-fund\"", kugou, "酷狗服务 npm 依赖");

            Log("安装 Python 自动化依赖 ...", Color.LightSkyBlue);
            var code = RunProcess("cmd.exe", "/d /s /c \"py -3.14 -m pip install --upgrade pywinauto pillow pywin32\"", projectPath, true);
            if (code != 0)
            {
                code = RunProcess("cmd.exe", "/d /s /c \"python -m pip install --upgrade pywinauto pillow pywin32\"", projectPath, true);
            }
            if (code != 0) throw new InvalidOperationException("Python 依赖安装失败。");
            Log("npm 与 Python 依赖已安装。", Color.LightGreen);
        }

        private void WarmOcr(string projectPath)
        {
            var script = Path.Combine(projectPath, ".setup-ocr.mjs");
            try
            {
                File.WriteAllText(script, "import { createWorker } from 'tesseract.js';\nconst worker = await createWorker('chi_sim+eng');\nawait worker.terminate();\n", new UTF8Encoding(false));
                Log("预下载 OCR 中文和英文模型，首次下载可能需要几分钟 ...", Color.LightSkyBlue);
                RunRequired("cmd.exe", "/d /s /c \"node \"\"" + script + "\"\"\"", Path.Combine(projectPath, "services", "qq-call-bridge"), "OCR 模型");
                Log("OCR 模型已缓存。", Color.LightGreen);
            }
            finally
            {
                if (File.Exists(script)) File.Delete(script);
            }
        }

        private void PrepareProject(string projectPath)
        {
            Log("生成本地配置和运行目录 ...", Color.LightSkyBlue);
            Directory.CreateDirectory(Path.Combine(projectPath, "data"));
            Directory.CreateDirectory(Path.Combine(projectPath, "music"));
            Directory.CreateDirectory(Path.Combine(projectPath, "music", "kugou-cache"));
            Directory.CreateDirectory(Path.Combine(projectPath, "services", "qq-call-bridge", "temp"));
            var config = Path.Combine(projectPath, "config.json");
            if (!File.Exists(config)) File.Copy(Path.Combine(projectPath, "config.example.json"), config);
            Log("项目本地配置已准备。", Color.LightGreen);
        }

        private void CreateShortcuts(string projectPath)
        {
            Log("生成桌面启动快捷方式 ...", Color.LightSkyBlue);
            var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            CreateShortcut(Path.Combine(desktop, "启动 PulseOps.lnk"), Path.Combine(projectPath, "start.bat"), projectPath, "启动 PulseOps 音乐机器人");
            var napCatLoader = Path.Combine(projectPath, "NapCat.Framework", "napiLoader.bat");
            if (File.Exists(napCatLoader)) CreateShortcut(Path.Combine(desktop, "启动 NapCat.lnk"), napCatLoader, Path.GetDirectoryName(napCatLoader), "启动 NapCat Framework");
            Log("桌面快捷方式已生成。", Color.LightGreen);
        }

        private void CreateShortcut(string shortcutPath, string targetPath, string workingDirectory, string description)
        {
            var shellType = Type.GetTypeFromProgID("WScript.Shell");
            var shell = Activator.CreateInstance(shellType);
            var shortcut = shellType.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { shortcutPath });
            var shortcutType = shortcut.GetType();
            shortcutType.InvokeMember("TargetPath", BindingFlags.SetProperty, null, shortcut, new object[] { targetPath });
            shortcutType.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, shortcut, new object[] { workingDirectory });
            shortcutType.InvokeMember("Description", BindingFlags.SetProperty, null, shortcut, new object[] { description });
            shortcutType.InvokeMember("Save", BindingFlags.InvokeMethod, null, shortcut, null);
        }

        private void ExtractZipOverwrite(string archivePath, string targetDirectory)
        {
            var targetRoot = Path.GetFullPath(targetDirectory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            using (var archive = ZipFile.OpenRead(archivePath))
            {
                foreach (var entry in archive.Entries)
                {
                    var destination = Path.GetFullPath(Path.Combine(targetDirectory, entry.FullName));
                    if (!destination.StartsWith(targetRoot, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("NapCat 压缩包包含不安全路径。");
                    if (string.IsNullOrEmpty(entry.Name))
                    {
                        Directory.CreateDirectory(destination);
                        continue;
                    }
                    Directory.CreateDirectory(Path.GetDirectoryName(destination));
                    using (var input = entry.Open())
                    using (var output = new FileStream(destination, FileMode.Create, FileAccess.Write, FileShare.None)) input.CopyTo(output);
                }
            }
        }

        private WebClient CreateWebClient()
        {
            var client = new WebClient();
            client.Headers[HttpRequestHeader.UserAgent] = "PulseOps-Environment-Setup/1.0";
            client.Headers[HttpRequestHeader.Accept] = "application/vnd.github+json";
            return client;
        }

        private void RunRequired(string fileName, string arguments, string workingDirectory, string displayName)
        {
            var exitCode = RunProcess(fileName, arguments, workingDirectory, true);
            if (exitCode != 0) throw new InvalidOperationException(displayName + " 安装失败，退出码：" + exitCode);
        }

        private int RunProcess(string fileName, string arguments, string workingDirectory, bool echoOutput)
        {
            var info = new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                WorkingDirectory = string.IsNullOrWhiteSpace(workingDirectory) ? Environment.CurrentDirectory : workingDirectory,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            using (var process = new Process { StartInfo = info })
            {
                process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (echoOutput && !string.IsNullOrWhiteSpace(e.Data)) Log(e.Data, Color.Gainsboro); };
                process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (echoOutput && !string.IsNullOrWhiteSpace(e.Data)) Log(e.Data, Color.Khaki); };
                try
                {
                    process.Start();
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException("无法启动 " + fileName + "：" + ex.Message, ex);
                }
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();
                process.WaitForExit();
                return process.ExitCode;
            }
        }

        private void RefreshPath()
        {
            var machine = Environment.GetEnvironmentVariable("Path", EnvironmentVariableTarget.Machine) ?? string.Empty;
            var user = Environment.GetEnvironmentVariable("Path", EnvironmentVariableTarget.User) ?? string.Empty;
            Environment.SetEnvironmentVariable("Path", machine + ";" + user, EnvironmentVariableTarget.Process);
        }

        private void SetRunning(bool running)
        {
            if (InvokeRequired) { Invoke(new Action<bool>(SetRunning), running); return; }
            installButton.Enabled = !running;
            browseButton.Enabled = !running;
            projectPathBox.Enabled = !running;
            foreach (var option in optionBoxes) option.Enabled = !running;
        }

        private void SetStatus(string text, int percent)
        {
            if (InvokeRequired) { Invoke(new Action<string, int>(SetStatus), text, percent); return; }
            statusLabel.Text = text;
            progressBar.Value = Math.Max(0, Math.Min(100, percent));
        }

        private void Log(string message, Color color)
        {
            if (InvokeRequired) { BeginInvoke(new Action<string, Color>(Log), message, color); return; }
            var line = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + message;
            logBox.SelectionStart = logBox.TextLength;
            logBox.SelectionColor = color;
            logBox.AppendText(line + Environment.NewLine);
            logBox.ScrollToCaret();
            try { File.AppendAllText(logFile, line + Environment.NewLine, new UTF8Encoding(false)); } catch { }
        }
    }

    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
