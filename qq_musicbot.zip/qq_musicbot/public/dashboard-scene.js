const canvas = document.querySelector('#dashboardScene');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

async function bootScene() {
  if (!canvas || reduceMotion) return;

  const THREE = await import('/vendor/three.module.js');
  const renderer = new THREE.WebGLRenderer({
    canvas,
    alpha: true,
    antialias: true,
    powerPreference: 'high-performance'
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(46, window.innerWidth / window.innerHeight, 0.1, 120);
  camera.position.set(0, 0, 15);

  const world = new THREE.Group();
  scene.add(world);

  const core = new THREE.Group();
  core.position.set(5.5, -0.2, -2.5);
  world.add(core);

  const shellMaterial = new THREE.MeshBasicMaterial({
    color: 0x42d7ff,
    transparent: true,
    opacity: 0.12,
    wireframe: true,
    blending: THREE.AdditiveBlending
  });
  const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(3.1, 2), shellMaterial);
  core.add(shell);

  const innerMaterial = new THREE.MeshBasicMaterial({
    color: 0x7c6cff,
    transparent: true,
    opacity: 0.09,
    wireframe: true,
    blending: THREE.AdditiveBlending
  });
  const inner = new THREE.Mesh(new THREE.OctahedronGeometry(2.05, 2), innerMaterial);
  inner.rotation.set(0.5, 0.25, 0.2);
  core.add(inner);

  const ringMaterial = new THREE.MeshBasicMaterial({
    color: 0x4ddfff,
    transparent: true,
    opacity: 0.12,
    wireframe: true,
    blending: THREE.AdditiveBlending
  });
  const ringSettings = [
    [3.9, 0.018, 0.25],
    [4.65, 0.012, -0.65],
    [5.35, 0.009, 1.05]
  ];
  const rings = ringSettings.map(([radius, tube, tilt], index) => {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(radius, tube, 8, 180), ringMaterial.clone());
    ring.material.opacity -= index * 0.025;
    ring.rotation.set(Math.PI / 2 + tilt, tilt * 0.45, tilt);
    core.add(ring);
    return ring;
  });

  const nodeGeometry = new THREE.SphereGeometry(0.035, 7, 7);
  const nodeMaterial = new THREE.MeshBasicMaterial({
    color: 0xc9f7ff,
    transparent: true,
    opacity: 0.55,
    blending: THREE.AdditiveBlending
  });
  const positions = shell.geometry.attributes.position;
  for (let index = 0; index < positions.count; index += 10) {
    const node = new THREE.Mesh(nodeGeometry, nodeMaterial);
    node.position.fromBufferAttribute(positions, index);
    core.add(node);
  }

  const particleCount = window.innerWidth < 760 ? 360 : 920;
  const particlePositions = new Float32Array(particleCount * 3);
  const particleColors = new Float32Array(particleCount * 3);
  const cyan = new THREE.Color(0x2bd9ff);
  const violet = new THREE.Color(0x7968ff);
  const color = new THREE.Color();

  for (let index = 0; index < particleCount; index += 1) {
    const offset = index * 3;
    const radius = 7 + Math.random() * 30;
    const angle = Math.random() * Math.PI * 2;
    particlePositions[offset] = Math.cos(angle) * radius + (Math.random() - 0.5) * 8;
    particlePositions[offset + 1] = (Math.random() - 0.5) * 18;
    particlePositions[offset + 2] = Math.sin(angle) * radius - 8 - Math.random() * 18;
    color.copy(cyan).lerp(violet, Math.random());
    particleColors[offset] = color.r;
    particleColors[offset + 1] = color.g;
    particleColors[offset + 2] = color.b;
  }

  const particleGeometry = new THREE.BufferGeometry();
  particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
  particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));
  const particles = new THREE.Points(
    particleGeometry,
    new THREE.PointsMaterial({
      size: 0.035,
      vertexColors: true,
      transparent: true,
      opacity: 0.45,
      sizeAttenuation: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    })
  );
  world.add(particles);

  const lineCount = 34;
  const linePositions = new Float32Array(lineCount * 6);
  for (let index = 0; index < lineCount; index += 1) {
    const offset = index * 6;
    const startX = -12 + Math.random() * 24;
    const startY = -7 + Math.random() * 14;
    const startZ = -10 - Math.random() * 14;
    linePositions[offset] = startX;
    linePositions[offset + 1] = startY;
    linePositions[offset + 2] = startZ;
    linePositions[offset + 3] = startX + (Math.random() - 0.5) * 3.5;
    linePositions[offset + 4] = startY + (Math.random() - 0.5) * 3.5;
    linePositions[offset + 5] = startZ + (Math.random() - 0.5) * 2;
  }
  const lineGeometry = new THREE.BufferGeometry();
  lineGeometry.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));
  const network = new THREE.LineSegments(
    lineGeometry,
    new THREE.LineBasicMaterial({ color: 0x5bcfff, transparent: true, opacity: 0.07, blending: THREE.AdditiveBlending })
  );
  world.add(network);

  const pointer = new THREE.Vector2();
  window.addEventListener('pointermove', (event) => {
    pointer.x = event.clientX / window.innerWidth - 0.5;
    pointer.y = event.clientY / window.innerHeight - 0.5;
  }, { passive: true });

  let frameId;
  const clock = new THREE.Clock();
  function render() {
    const elapsed = clock.getElapsedTime();
    core.rotation.y = elapsed * 0.045 + pointer.x * 0.16;
    core.rotation.x = Math.sin(elapsed * 0.22) * 0.05 + pointer.y * 0.08;
    inner.rotation.y = -elapsed * 0.085;
    inner.rotation.z = elapsed * 0.035;
    rings[0].rotation.z = elapsed * 0.022;
    rings[1].rotation.z = -elapsed * 0.018;
    rings[2].rotation.y = elapsed * 0.014;
    particles.rotation.y = elapsed * 0.0025;
    network.rotation.y = -elapsed * 0.003;
    world.position.x += (pointer.x * 0.35 - world.position.x) * 0.018;
    world.position.y += (-pointer.y * 0.22 - world.position.y) * 0.018;
    renderer.render(scene, camera);
    frameId = requestAnimationFrame(render);
  }

  function resize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
    renderer.setSize(window.innerWidth, window.innerHeight);
    core.position.x = window.innerWidth < 900 ? 2.7 : 5.5;
  }

  window.addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      cancelAnimationFrame(frameId);
    } else {
      clock.getDelta();
      render();
    }
  });

  render();
}

bootScene().catch(() => document.body.classList.add('scene-fallback'));
