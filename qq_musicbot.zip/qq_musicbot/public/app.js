const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
let overview = null;
let logs = [];
let mockActive = false;
let qrTimer = null;

function toast(message) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(element.timer);
  element.timer = setTimeout(() => element.classList.remove('show'), 2600);
}

async function api(path, options = {}) {
  const response = await fetch(path, { headers: { 'content-type': 'application/json' }, ...options });
  const data = await response.json().catch(() => ({}));
  if (response.status === 401) {
    location.replace(`/login?next=${encodeURIComponent(location.pathname + location.search)}`);
    throw new Error('登录状态已失效');
  }
  if (!response.ok) throw new Error(data.message || `HTTP ${response.status}`);
  return data;
}

function time(value) {
  return new Date(value).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function renderState(state) {
  $('#commandsMetric').textContent = state.commands;
  $('#playedMetric').textContent = state.played;
  $('#rejectedMetric').textContent = state.rejected;
  $('#errorsMetric').textContent = state.errors;
  $('#successRate').textContent = `${state.commands ? Math.round(state.played / state.commands * 100) : 0}%`;
  const uptime = Math.max(0, Date.now() - new Date(state.startedAt).getTime());
  $('#uptimeMetric').textContent = `${Math.floor(uptime / 3600000)}H`;
  $('#napcatDot').classList.toggle('online', state.napcatConnected);
  $('#bridgeDot').classList.toggle('online', state.bridgeConnected);
  $('#napcatStatus').textContent = state.napcatConnected ? '连接正常' : '等待连接';
  $('#bridgeStatus').textContent = state.bridgeConnected ? '运行正常' : '不可用';
  $('#sideStatus').textContent = state.napcatConnected ? 'Gateway Online' : 'Gateway Offline';
  const healthy = Number(state.napcatConnected) + Number(state.bridgeConnected);
  const percent = healthy * 50;
  $('#healthyCount').textContent = `${healthy}/2`;
  $('#healthScore').textContent = `${percent}%`;
  $('#ringValue').style.strokeDashoffset = 314 - 314 * percent / 100;
  const current = state.current;
  $('.now-card').classList.toggle('playing', Boolean(current));
  $('#playingGroup').textContent = current ? `GROUP · ${current.groupId}` : '等待群通话';
  $('#playingTitle').textContent = current?.title || '暂无播放任务';
  $('#playingMeta').textContent = current ? `由 ${current.userId} 点播 · ${current.format}` : '系统已就绪，等待 /music 指令';
  $('#playProgress').style.width = current ? '68%' : '0%';
  $('#playingTime').textContent = current ? time(current.startedAt).slice(0, 5) : '--:--';
  renderChart(state.activity);
}

function renderChart(points) {
  const svg = $('#activityChart');
  const max = Math.max(4, ...points.map((point) => point.value));
  const width = 760;
  const height = 215;
  const coordinates = points.map((point, index) => ({ x: index * width / (points.length - 1), y: height - point.value / max * 165 - 18 }));
  const line = coordinates.map((point, index) => `${index ? 'L' : 'M'} ${point.x} ${point.y}`).join(' ');
  const area = `${line} L ${width} ${height} L 0 ${height} Z`;
  svg.innerHTML = `<defs><linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#23d7f2" stop-opacity=".23"/><stop offset="1" stop-color="#23d7f2" stop-opacity="0"/></linearGradient></defs><path class="chart-area" d="${area}"/><path class="chart-line" d="${line}"/>${coordinates.map((point) => `<circle class="chart-dot" cx="${point.x}" cy="${point.y}" r="3"/>`).join('')}`;
  $('#chartLabels').innerHTML = points.filter((_, index) => index % 2 === 0).map((point) => `<span>${point.label}</span>`).join('');
}

function renderLogs() {
  const feedItems = logs.slice(0, 6);
  $('#eventFeed').innerHTML = feedItems.length ? feedItems.map((entry) => `<div class="event ${entry.level}"><span></span><p>${entry.message}</p><time>${time(entry.time).slice(0, 5)}</time></div>`).join('') : '<div class="empty">暂无系统事件</div>';
  $('#fullLogs').innerHTML = logs.length ? logs.map((entry) => `<div class="log-line ${entry.level}"><time>${time(entry.time)}</time><b>${entry.level.toUpperCase()}</b><span>${entry.message}</span></div>`).join('') : '<div class="empty">暂无日志</div>';
}

function renderConfig(data) {
  $('#bridgeMode').textContent = data.config.bridgeMode.toUpperCase();
  $('#settingsBridgeMode').textContent = data.config.bridgeMode;
  $('#httpUrl').textContent = data.config.napcatHttpUrl;
  $('#wsUrl').textContent = data.config.napcatWsUrl;
  $('#commandName').textContent = data.config.command;
  $('#musicDirectory').textContent = data.config.musicDirectory;
  $('#libraryCount').textContent = data.libraryCount;
  $('#mockRow').style.display = data.config.bridgeMode === 'mock' ? 'flex' : 'none';
  renderKugouStatus(data.kugou);
}

function renderKugouStatus(status) {
  const loggedIn = status?.loggedIn === true;
  $('#kugouDot').classList.toggle('online', loggedIn);
  $('#kugouState').textContent = loggedIn ? '账号已连接' : status?.ready ? '等待扫码登录' : '适配服务启动中';
  $('#kugouUser').textContent = loggedIn ? status.user?.nickname || `用户 ${status.user?.id || ''}` : '未连接账号';
  $('#kugouLoginButton').style.display = loggedIn ? 'none' : 'inline-block';
  $('#kugouLogoutButton').style.display = loggedIn ? 'inline-block' : 'none';
}

function closeQrModal() {
  $('#kugouModal').classList.remove('open');
  clearInterval(qrTimer);
  qrTimer = null;
}

async function createQr() {
  clearInterval(qrTimer);
  $('#kugouModal').classList.add('open');
  $('#qrStatus').textContent = '正在生成二维码';
  $('#qrImage').removeAttribute('src');
  try {
    const qr = await api('/api/kugou/qr', { method: 'POST', body: '{}' });
    $('#qrImage').src = qr.image;
    $('#qrStatus').textContent = '等待扫码';
    qrTimer = setInterval(async () => {
      try {
        const status = await api(`/api/kugou/qr/${encodeURIComponent(qr.key)}/status`);
        const labels = { 0: '二维码已过期', 1: '等待扫码', 2: '已扫码，请在手机确认', 4: '登录成功' };
        $('#qrStatus').textContent = labels[status.status] || `状态 ${status.status}`;
        if (status.loggedIn) {
          clearInterval(qrTimer);
          renderKugouStatus({ ready: true, loggedIn: true, user: status.user });
          toast('酷狗音乐登录成功');
          setTimeout(closeQrModal, 900);
        } else if (status.status === 0) clearInterval(qrTimer);
      } catch (error) { $('#qrStatus').textContent = error.message; }
    }, 2000);
  } catch (error) { $('#qrStatus').textContent = `二维码生成失败：${error.message}`; }
}

async function searchKugou() {
  const query = $('#kugouSearch').value.trim();
  if (!query) return toast('请输入歌曲或歌手名称');
  $('#kugouResults').innerHTML = '<div class="empty">正在搜索酷狗曲库…</div>';
  try {
    const tracks = await api(`/api/kugou/search?q=${encodeURIComponent(query)}`);
    $('#kugouResults').innerHTML = tracks.length ? tracks.map((track) => `<div class="cloud-track"><span>♫</span><div><strong>${track.title}</strong><small>${track.artist || '未知歌手'}</small></div><span class="cloud-album">${track.album || '单曲'}</span><span class="cloud-duration">${track.duration ? `${Math.floor(track.duration / 60)}:${String(track.duration % 60).padStart(2, '0')}` : '--:--'}</span></div>`).join('') : '<div class="empty">没有找到相关歌曲</div>';
  } catch (error) { $('#kugouResults').innerHTML = `<div class="empty">${error.message}</div>`; }
}

async function loadOverview() {
  overview = await api('/api/overview');
  logs = overview.logs;
  renderState(overview.state);
  renderConfig(overview);
  renderLogs();
}

async function loadLibrary(query = '') {
  const tracks = await api(`/api/library${query ? `?q=${encodeURIComponent(query)}` : ''}`);
  $('#trackTable').innerHTML = tracks.length ? tracks.map((track, index) => `<div class="track-row"><span class="track-index">${String(index + 1).padStart(2, '0')}</span><span class="track-title">${track.title}</span><span class="track-path">${track.file}</span><span class="format-badge">${track.format}</span></div>`).join('') : '<div class="empty">音乐库为空，请将音频放入 music 文件夹</div>';
}

function showView(name) {
  $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === name));
  $$('.view').forEach((view) => view.classList.toggle('active', view.id === `${name}View`));
  $('#pageTitle').textContent = { overview: '运行总览', library: '音乐资产', kugou: '酷狗音乐', console: '指令与日志', settings: '系统配置' }[name];
  if (name === 'library') loadLibrary();
}

$$('.nav-item').forEach((button) => button.addEventListener('click', () => showView(button.dataset.view)));
$$('[data-target]').forEach((button) => button.addEventListener('click', () => showView(button.dataset.target)));
$('#refreshButton').addEventListener('click', () => loadOverview().then(() => toast('数据已刷新')));
$('#logoutButton').addEventListener('click', async () => {
  try { await api('/api/auth/logout', { method: 'POST', body: '{}' }); }
  finally { location.replace('/login'); }
});
$('#librarySearch').addEventListener('input', (event) => loadLibrary(event.target.value));
$('#rescanButton').addEventListener('click', async () => {
  const result = await api('/api/library/rescan', { method: 'POST', body: '{}' });
  $('#libraryCount').textContent = result.count;
  await loadLibrary();
  toast(`已扫描 ${result.count} 首音乐`);
});
$('#mockToggle').addEventListener('click', async () => {
  mockActive = !mockActive;
  await api('/api/mock-call', { method: 'POST', body: JSON.stringify({ groupId: $('#testGroup').value, active: mockActive }) });
  $('#mockToggle').classList.toggle('active', mockActive);
  toast(mockActive ? '模拟群通话已开启' : '模拟群通话已关闭');
});
$('#testButton').addEventListener('click', async () => {
  const query = $('#testQuery').value.trim();
  if (!query) return toast('请输入音乐名');
  $('#testButton').disabled = true;
  try {
    await api('/api/test-command', { method: 'POST', body: JSON.stringify({ groupId: $('#testGroup').value, query }) });
    toast('测试指令已执行');
  } catch (error) { toast(error.message); }
  finally { $('#testButton').disabled = false; }
});
$('#stopButton').addEventListener('click', async () => {
  try { await api('/api/stop', { method: 'POST', body: JSON.stringify({ groupId: overview?.state.current?.groupId }) }); toast('已发送停止指令'); }
  catch (error) { toast(error.message); }
});
$('#kugouLoginButton').addEventListener('click', createQr);
$('#refreshQr').addEventListener('click', createQr);
$('#qrClose').addEventListener('click', closeQrModal);
$('#kugouModal').addEventListener('click', (event) => { if (event.target === $('#kugouModal')) closeQrModal(); });
$('#kugouSearchButton').addEventListener('click', searchKugou);
$('#kugouSearch').addEventListener('keydown', (event) => { if (event.key === 'Enter') searchKugou(); });
$('#kugouLogoutButton').addEventListener('click', async () => {
  await api('/api/kugou/logout', { method: 'POST', body: '{}' });
  renderKugouStatus({ ready: true, loggedIn: false });
  $('#kugouResults').innerHTML = '<div class="empty">登录后即可检索酷狗音乐</div>';
  toast('已退出酷狗音乐');
});

setInterval(() => { $('#clock').textContent = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }); }, 1000);
const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
const live = new WebSocket(`${protocol}//${location.host}/live`);
live.addEventListener('message', (event) => {
  const message = JSON.parse(event.data);
  if (message.type === 'state') { overview = overview || {}; overview.state = message.data; renderState(message.data); }
  if (message.type === 'log') { logs.unshift(message.data); logs = logs.slice(0, 100); renderLogs(); }
});

loadOverview().then(() => {
  if (new URLSearchParams(location.search).get('kugouLogin') === '1') {
    showView('kugou');
    createQr();
  }
}).catch((error) => toast(`加载失败：${error.message}`));
