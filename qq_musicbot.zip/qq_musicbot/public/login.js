const canvas = document.querySelector('#scene');
const form = document.querySelector('#loginForm');
const input = document.querySelector('#tokenInput');
const toggle = document.querySelector('#toggleToken');
const button = document.querySelector('#loginButton');
const message = document.querySelector('#formMessage');
const card = document.querySelector('.login-card');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function safeNextPath() {
  const next = new URLSearchParams(location.search).get('next');
  return next?.startsWith('/') && !next.startsWith('//') ? next : '/';
}

async function checkSession() {
  try {
    const response = await fetch('/api/auth/status', { cache: 'no-store' });
    const status = await response.json();
    if (status.authenticated) location.replace(safeNextPath());
  } catch {}
}

toggle.addEventListener('click', () => {
  const visible = input.type === 'text';
  input.type = visible ? 'password' : 'text';
  toggle.textContent = visible ? 'SHOW' : 'HIDE';
  toggle.setAttribute('aria-label', visible ? '显示 Token' : '隐藏 Token');
  input.focus();
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const token = input.value.trim();
  if (!token) {
    message.textContent = '请输入管理后台 Token。';
    input.focus();
    return;
  }
  button.disabled = true;
  button.classList.add('loading');
  message.textContent = '';
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ token })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || '登录失败');
    card.classList.add('success');
    message.style.color = '#51efbc';
    message.textContent = '身份验证通过，正在建立安全会话…';
    setTimeout(() => location.replace(safeNextPath()), 520);
  } catch (error) {
    message.style.color = '';
    message.textContent = error.message;
    card.classList.remove('shake');
    requestAnimationFrame(() => card.classList.add('shake'));
    button.disabled = false;
    button.classList.remove('loading');
    input.select();
  }
});

if (location.protocol === 'https:') {
  document.querySelector('#transportLabel').textContent = 'TLS ENCRYPTED';
  document.querySelector('#transportHint').textContent = '当前连接已通过 HTTPS 加密';
}

async function createScene() {
  if (!canvas || reduceMotion) return;
  const THREE = await import('/vendor/three.module.js');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
  renderer.setSize(innerWidth, innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x050914, 0.055);
  const camera = new THREE.PerspectiveCamera(48, innerWidth / innerHeight, 0.1, 100);
  camera.position.set(0, 0, 10.5);
  const core = new THREE.Group();
  core.position.set(innerWidth > 1050 ? -2.8 : 0, 0.15, 0);
  scene.add(core);

  const shell = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.65, 2),
    new THREE.MeshBasicMaterial({ color: 0x5bdfff, wireframe: true, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending })
  );
  core.add(shell);
  const inner = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.08, 1),
    new THREE.MeshBasicMaterial({ color: 0x6d68ff, wireframe: true, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending })
  );
  inner.rotation.set(0.3, 0.5, 0.1);
  core.add(inner);

  const nodeGeometry = new THREE.SphereGeometry(0.025, 6, 6);
  const nodeMaterial = new THREE.MeshBasicMaterial({ color: 0xb8f7ff, transparent: true, opacity: 0.8 });
  const vertices = shell.geometry.attributes.position;
  for (let index = 0; index < vertices.count; index += 9) {
    const node = new THREE.Mesh(nodeGeometry, nodeMaterial);
    node.position.fromBufferAttribute(vertices, index);
    core.add(node);
  }

  const ringMaterial = new THREE.MeshBasicMaterial({ color: 0x667dff, transparent: true, opacity: 0.18, wireframe: true, blending: THREE.AdditiveBlending });
  for (const [radius, tube, rotation] of [[2.25, .012, .45], [2.75, .009, -.65], [3.25, .007, 1.05]]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(radius, tube, 8, 150), ringMaterial.clone());
    ring.rotation.set(Math.PI / 2 + rotation, rotation * .4, rotation);
    core.add(ring);
  }

  const particleCount = innerWidth < 700 ? 420 : 900;
  const positions = new Float32Array(particleCount * 3);
  const colors = new Float32Array(particleCount * 3);
  const cyan = new THREE.Color(0x54dfff);
  const violet = new THREE.Color(0x8b69ff);
  for (let index = 0; index < particleCount; index++) {
    const radius = 6 + Math.random() * 22;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    positions[index * 3] = radius * Math.sin(phi) * Math.cos(theta);
    positions[index * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta) * .6;
    positions[index * 3 + 2] = radius * Math.cos(phi);
    const color = cyan.clone().lerp(violet, Math.random());
    colors[index * 3] = color.r;
    colors[index * 3 + 1] = color.g;
    colors[index * 3 + 2] = color.b;
  }
  const particleGeometry = new THREE.BufferGeometry();
  particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const particles = new THREE.Points(particleGeometry, new THREE.PointsMaterial({ size: .035, vertexColors: true, transparent: true, opacity: .62, depthWrite: false, blending: THREE.AdditiveBlending }));
  scene.add(particles);

  const grid = new THREE.GridHelper(42, 42, 0x26395c, 0x16223a);
  grid.position.y = -4.7;
  grid.material.transparent = true;
  grid.material.opacity = .16;
  scene.add(grid);

  const pointer = new THREE.Vector2();
  addEventListener('pointermove', (event) => {
    pointer.x = event.clientX / innerWidth - .5;
    pointer.y = event.clientY / innerHeight - .5;
  }, { passive: true });

  const clock = new THREE.Clock();
  function animate() {
    const elapsed = clock.getElapsedTime();
    core.rotation.y = elapsed * .09 + pointer.x * .22;
    core.rotation.x = Math.sin(elapsed * .28) * .08 + pointer.y * .12;
    inner.rotation.y = -elapsed * .16;
    particles.rotation.y = elapsed * .008;
    particles.rotation.x = pointer.y * .04;
    camera.position.x += (pointer.x * .35 - camera.position.x) * .025;
    camera.position.y += (-pointer.y * .24 - camera.position.y) * .025;
    camera.lookAt(0, 0, 0);
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  animate();

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
    core.position.x = innerWidth > 1050 ? -2.8 : 0;
  });
}

createScene().catch(() => document.body.classList.add('webgl-fallback'));

checkSession();
