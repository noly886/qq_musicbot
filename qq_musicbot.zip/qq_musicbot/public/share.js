const audio = document.querySelector('#audio');
const playButton = document.querySelector('#playButton');
const playIcon = document.querySelector('#playIcon');
const playLabel = document.querySelector('#playLabel');
const volume = document.querySelector('#volume');
const volumeLabel = document.querySelector('#volumeLabel');
const progressBar = document.querySelector('#progressBar');
const currentTime = document.querySelector('#currentTime');
const durationTime = document.querySelector('#durationTime');
const closedScreen = document.querySelector('#closedScreen');
const canvas = document.querySelector('#visualizer');
const context = canvas.getContext('2d');
const token = location.pathname.split('/').filter(Boolean).at(-1) || '';
let room = null;
let audioContext;
let analyser;
let source;
let synced = false;
let closed = false;
let lyrics = [];
let activeLyricIndex = -1;

function time(value) {
  if (!Number.isFinite(value) || value < 0) return '--:--';
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60);
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function setText(selector, value) {
  document.querySelector(selector).textContent = value;
}

function roomEnded() {
  if (closed) return;
  closed = true;
  audio.pause();
  audio.removeAttribute('src');
  audio.load();
  setText('#connectionLabel', '已关闭');
  closedScreen.classList.add('show');
}

function renderRoom(data) {
  room = data;
  if (!data.active) return roomEnded();
  document.title = `${data.title} · PulseWave`;
  setText('#trackTitle', data.title);
  setText('#coverTitle', data.title);
  setText('#stageTitle', data.title);
  setText('#queueTitle', data.title);
  setText('#requestedBy', data.requestedBy || 'Anonymous');
  setText('#groupLabel', data.group || 'Private');
  setText('#formatLabel', data.format || 'AUDIO');
  setText('#connectionLabel', '已连接');
  setText('#startedAt', `SESSION / ${new Date(data.startedAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}`);
  if (!lyrics.length && Array.isArray(data.lyrics)) {
    lyrics = data.lyrics.filter((line) => line && Number.isFinite(Number(line.time)) && line.text)
      .map((line) => ({ time: Number(line.time), text: String(line.text) }));
    renderLyrics(-1);
  }
  if (!audio.src) audio.src = data.mediaUrl;
}

function renderLyrics(index) {
  const field = document.querySelector('#lyricField');
  if (!lyrics.length) {
    field.innerHTML = `<p>Voice automation connected</p><p>Secure temporary transmission</p><p class="active">${room?.title || '正在播放音乐'}</p><p>当前歌曲暂无可用歌词</p><p>The signal ends when the music ends</p>`;
    return;
  }
  const center = Math.max(0, index);
  const start = Math.max(0, Math.min(lyrics.length - 7, center - 3));
  const visible = lyrics.slice(start, start + 7);
  field.innerHTML = visible.map((line, offset) => {
    const lineIndex = start + offset;
    return `<p class="${lineIndex === index ? 'active' : ''}" data-index="${lineIndex}">${escapeHtml(line.text)}</p>`;
  }).join('');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function updateLyrics(position) {
  if (!lyrics.length) return;
  let nextIndex = -1;
  for (let index = 0; index < lyrics.length; index += 1) {
    if (lyrics[index].time <= position + .15) nextIndex = index;
    else break;
  }
  if (nextIndex === activeLyricIndex) return;
  activeLyricIndex = nextIndex;
  renderLyrics(nextIndex);
}

async function loadRoom() {
  try {
    const response = await fetch(`/api/rooms/${encodeURIComponent(token)}`, { cache: 'no-store' });
    if (!response.ok) return roomEnded();
    renderRoom(await response.json());
  } catch {
    setText('#connectionLabel', '重连中');
  }
}

function setupAudioGraph() {
  if (audioContext) return;
  audioContext = new AudioContext();
  analyser = audioContext.createAnalyser();
  analyser.fftSize = 128;
  source = audioContext.createMediaElementSource(audio);
  source.connect(analyser);
  analyser.connect(audioContext.destination);
}

playButton.addEventListener('click', async () => {
  if (closed) return;
  setupAudioGraph();
  await audioContext.resume();
  if (audio.paused) {
    await audio.play();
  } else {
    audio.pause();
  }
});

audio.addEventListener('play', () => {
  playIcon.textContent = 'Ⅱ';
  playLabel.textContent = '暂停播放';
});

audio.addEventListener('pause', () => {
  playIcon.textContent = '▶';
  playLabel.textContent = '播放音乐';
});

audio.addEventListener('loadedmetadata', () => {
  durationTime.textContent = time(audio.duration);
  setText('#queueDuration', time(audio.duration));
  if (!synced && room?.startedAt && Number.isFinite(audio.duration)) {
    const elapsed = Math.max(0, (Date.now() - Date.parse(room.startedAt)) / 1000);
    if (elapsed < audio.duration - 1) audio.currentTime = elapsed;
    synced = true;
  }
});

audio.addEventListener('timeupdate', () => {
  currentTime.textContent = time(audio.currentTime);
  const progress = audio.duration ? Math.min(100, audio.currentTime / audio.duration * 100) : 0;
  progressBar.style.width = `${progress}%`;
  updateLyrics(audio.currentTime);
});

audio.addEventListener('ended', loadRoom);
volume.addEventListener('input', () => {
  audio.volume = Number(volume.value);
  volumeLabel.textContent = `${Math.round(audio.volume * 100)}%`;
});
audio.volume = Number(volume.value);
document.querySelector('#reloadButton').addEventListener('click', () => location.reload());
document.querySelector('#closeButton').addEventListener('click', () => {
  window.close();
  setTimeout(() => { location.href = 'about:blank'; }, 100);
});

function draw() {
  const ratio = Math.min(devicePixelRatio, 1.5);
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  if (canvas.width !== width * ratio || canvas.height !== height * ratio) {
    canvas.width = width * ratio;
    canvas.height = height * ratio;
  }
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.clearRect(0, 0, width, height);
  const bars = analyser ? analyser.frequencyBinCount : 42;
  const values = new Uint8Array(bars);
  if (analyser) analyser.getByteFrequencyData(values);
  const center = height / 2;
  const barWidth = width / bars;
  for (let index = 0; index < bars; index += 1) {
    const idle = 8 + Math.sin(Date.now() / 650 + index * .55) * 6;
    const amplitude = analyser ? values[index] / 255 * height * .32 : idle;
    const gradient = context.createLinearGradient(0, center - amplitude, 0, center + amplitude);
    gradient.addColorStop(0, 'rgba(118,109,255,0)');
    gradient.addColorStop(.5, 'rgba(118,109,255,.75)');
    gradient.addColorStop(1, 'rgba(90,217,255,0)');
    context.fillStyle = gradient;
    context.fillRect(index * barWidth + 1, center - amplitude, Math.max(1, barWidth - 3), amplitude * 2);
  }
  requestAnimationFrame(draw);
}

loadRoom();
setInterval(loadRoom, 1000);
draw();
