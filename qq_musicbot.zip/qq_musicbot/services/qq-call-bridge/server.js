import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { createWorker } from 'tesseract.js';

const execFileAsync = promisify(execFile);
const root = path.dirname(fileURLToPath(import.meta.url));
const tempDirectory = path.join(root, 'temp');
const soundVolumeView = path.join(root, 'tools', 'soundvolumeview', 'SoundVolumeView.exe');
const voiceMeeterRender = 'VB-Audio VoiceMeeter AUX VAIO\\Device\\VoiceMeeter Aux Input\\Render';
const voiceMeeterCapture = 'VB-Audio VoiceMeeter AUX VAIO\\Device\\VoiceMeeter Aux Output\\Capture';
fs.mkdirSync(tempDirectory, { recursive: true });
let worker = null;
let workerReady = false;
let player = null;
let taskQueue = Promise.resolve();

function serialized(task) {
  const result = taskQueue.then(task, task);
  taskQueue = result.catch(() => {});
  return result;
}

async function runUi(args) {
  const { stdout } = await execFileAsync('python', [path.join(root, 'qq_ui.py'), ...args], { timeout: 20000, windowsHide: true });
  const result = JSON.parse(stdout.trim().split(/\r?\n/).at(-1));
  if (!result.ok) throw new Error(result.error || 'QQ 自动化失败');
  return result;
}

async function routeProcess(device, processId) {
  if (!fs.existsSync(soundVolumeView)) throw new Error('SoundVolumeView 音频路由工具不存在');
  const volume = device === voiceMeeterRender ? '72' : '88';
  await execFileAsync(soundVolumeView, ['/SetDefaultFormat', device, '24', '48000', '2'], { timeout: 10000, windowsHide: true });
  await execFileAsync(soundVolumeView, ['/Unmute', device], { timeout: 10000, windowsHide: true });
  await execFileAsync(soundVolumeView, ['/SetVolume', device, volume], { timeout: 10000, windowsHide: true });
  await execFileAsync(soundVolumeView, ['/SetAppDefault', device, 'all', String(processId)], { timeout: 10000, windowsHide: true });
}

async function routeQqAudio() {
  const { stdout } = await execFileAsync('powershell.exe', [
    '-NoProfile',
    '-Command',
    "(Get-Process -Name QQ -ErrorAction SilentlyContinue).Id -join ','"
  ], { timeout: 10000, windowsHide: true });
  const processIds = stdout.trim().split(',').map(Number).filter(Number.isFinite);
  if (!processIds.length) throw new Error('没有找到正在运行的 QQ 进程');
  await Promise.all(processIds.map((processId) => routeProcess(voiceMeeterCapture, processId)));
}

function wordsFromTsv(tsv) {
  return tsv.split(/\r?\n/).slice(1).map((line) => {
    const fields = line.split('\t');
    if (fields.length < 12 || fields[0] !== '5') return null;
    return { left: Number(fields[6]), top: Number(fields[7]), width: Number(fields[8]), height: Number(fields[9]), confidence: Number(fields[10]), text: fields.slice(11).join('\t').trim() };
  }).filter((word) => word?.text && word.confidence > 20);
}

async function recognize(image) {
  const result = await worker.recognize(image, {}, { tsv: true });
  return { words: wordsFromTsv(result.data.tsv || ''), text: `${result.data.text || ''}`.replace(/\s+/g, '') };
}

async function openGroup(groupId) {
  await runUi(['open', '--group', String(groupId)]);
}

async function scanGroup(groupId) {
  if (!workerReady) throw new Error('界面识别引擎仍在初始化');
  await openGroup(groupId);
  const image = path.join(tempDirectory, `group-${groupId}-${Date.now()}.png`);
  const crop = [280, 80, 930, 570];
  const visual = await runUi(['callscan', '--output', image, '--crop', crop.join(',')]);
  const result = await recognize(image);
  fs.rmSync(image, { force: true });
  const cleanedText = result.text.replace(/语音通话已结束/g, '').replace(/无法检测群电话[^。]*/g, '');
  const joinWord = result.words.find((word) => /加入|进入|参与/.test(word.text));
  const active = Boolean(visual.active || (joinWord && /通话|语音/.test(cleanedText)) || /正在通话|通话中/.test(cleanedText));
  if (joinWord) {
    joinWord.left += crop[0];
    joinWord.top += crop[1];
  }
  const joinPoint = Number.isFinite(visual.joinX) && Number.isFinite(visual.joinY)
    ? { x: visual.joinX, y: visual.joinY }
    : null;
  return { active, joinPoint, joinWord, words: result.words, text: cleanedText, visual };
}

async function hangupCall() {
  const image = path.join(tempDirectory, `hangup-${Date.now()}.png`);
  try {
    await runUi(['hangup', '--output', image]);
    return true;
  } finally {
    fs.rmSync(image, { force: true });
  }
}

async function initialize() {
  worker = await createWorker('chi_sim+eng', 1, { logger: (message) => {
    if (message.status === 'recognizing text') process.stdout.write(`[OCR] ${Math.round((message.progress || 0) * 100)}%\n`);
  }});
  workerReady = true;
  process.stdout.write('QQ call bridge OCR ready\n');
}

const app = express();
app.use(express.json());

app.get('/v1/health', async (_request, response) => {
  let qq = false;
  try { qq = (await runUi(['probe'])).ok; } catch {}
  response.json({ ok: workerReady && qq, mode: 'windows', ocrReady: workerReady, qqAvailable: qq, audioRoute: '播放器 → VoiceMeeter Aux Input → VoiceMeeter Aux Output → QQ 麦克风' });
});

app.get('/v1/groups/:groupId/call', async (request, response) => {
  try {
    const result = await serialized(() => scanGroup(request.params.groupId));
    response.json({ active: result.active, detectedText: result.active ? '群通话' : '' });
  } catch (error) { response.status(500).json({ active: false, message: error.message }); }
});

app.post('/v1/groups/:groupId/join', async (request, response) => {
  try {
    await routeQqAudio();
    const result = await serialized(() => scanGroup(request.params.groupId));
    if (!result.active) return response.json({ ok: false, message: '没有识别到群通话入口' });
    if (result.joinPoint) {
      await runUi(['click', '--x', String(result.joinPoint.x), '--y', String(result.joinPoint.y)]);
    } else if (result.joinWord) {
      await runUi(['click', '--x', String(result.joinWord.left + result.joinWord.width / 2), '--y', String(result.joinWord.top + result.joinWord.height / 2)]);
    }
    response.json({ ok: true, joined: Boolean(result.joinPoint || result.joinWord) });
  } catch (error) { response.status(500).json({ ok: false, message: error.message }); }
});

app.post('/v1/groups/:groupId/play', async (request, response) => {
  const file = request.body.file;
  if (!file || !fs.existsSync(file)) return response.status(400).json({ ok: false, message: '音频文件不存在' });
  const initializedFile = path.join(tempDirectory, `player-initialized-${Date.now()}.flag`);
  const readyFile = path.join(tempDirectory, `player-ready-${Date.now()}.flag`);
  try {
    if (player) {
      player.autoLeave = false;
      player.process.kill();
    }
    const process = spawn('powershell.exe', [
      '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(root, 'play.ps1'),
      '-File', file, '-InitializedFile', initializedFile, '-ReadyFile', readyFile
    ], { windowsHide: true, stdio: 'ignore' });
    const playback = {
      id: crypto.randomUUID(),
      process,
      groupId: request.params.groupId,
      title: String(request.body.title || path.basename(file)),
      requestedBy: String(request.body.requestedBy || ''),
      startedAt: new Date().toISOString(),
      autoLeave: true
    };
    player = playback;
    for (let attempt = 0; attempt < 50 && !fs.existsSync(initializedFile); attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    if (!fs.existsSync(initializedFile)) throw new Error('播放器音频会话初始化超时');
    await routeProcess(voiceMeeterRender, process.pid);
    fs.writeFileSync(readyFile, 'ready');
    process.on('exit', async () => {
      if (player === playback) player = null;
      fs.rmSync(initializedFile, { force: true });
      fs.rmSync(readyFile, { force: true });
      if (playback.autoLeave) {
        try {
          await serialized(() => hangupCall());
        } catch (error) {
          console.warn(`自动退出群电话失败：${error.message}`);
        }
      }
    });
    response.json({ ok: true, playbackId: playback.id, startedAt: playback.startedAt });
  } catch (error) {
    if (player) {
      player.autoLeave = false;
      player.process.kill();
    }
    player = null;
    fs.rmSync(initializedFile, { force: true });
    fs.rmSync(readyFile, { force: true });
    response.status(500).json({ ok: false, message: error.message });
  }
});

app.get('/v1/playback', (_request, response) => {
  if (!player) return response.json({ active: false, supported: true });
  response.json({
    active: true,
    supported: true,
    playbackId: player.id,
    groupId: player.groupId,
    title: player.title,
    requestedBy: player.requestedBy,
    startedAt: player.startedAt
  });
});

app.post('/v1/groups/:groupId/stop', (_request, response) => {
  if (player) player.process.kill();
  response.json({ ok: true });
});

const port = Number(process.env.PORT || 3211);
app.listen(port, '127.0.0.1', () => process.stdout.write(`QQ call bridge listening on 127.0.0.1:${port}\n`));
initialize().catch((error) => process.stderr.write(`OCR initialization failed: ${error.stack || error}\n`));

for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, async () => { await worker?.terminate(); process.exit(0); });
