import argparse
import json
import time
from pathlib import Path

import win32api
import win32con
import win32gui
import win32process
from PIL import Image, ImageGrab
from pywinauto import Desktop, keyboard


def find_qq_window():
    candidates = []
    for window in Desktop(backend='uia').windows():
        try:
            if window.window_text() != 'QQ' or window.element_info.class_name != 'Chrome_WidgetWin_1':
                continue
            rect = window.rectangle()
            area = max(0, rect.width()) * max(0, rect.height())
            if area > 200000:
                candidates.append((area, window))
        except Exception:
            pass
    if not candidates:
        raise RuntimeError('未找到可用的 QQ 主窗口')
    return max(candidates, key=lambda item: item[0])[1]


def find_call_window():
    candidates = []
    for window in Desktop(backend='uia').windows():
        try:
            if window.window_text() != '语音通话' or window.element_info.class_name != 'Chrome_WidgetWin_1':
                continue
            rect = window.rectangle()
            area = max(0, rect.width()) * max(0, rect.height())
            if area > 150000:
                candidates.append((area, window))
        except Exception:
            pass
    if not candidates:
        raise RuntimeError('未找到 QQ 语音通话窗口')
    return max(candidates, key=lambda item: item[0])[1]


def focus(window):
    hwnd = window.handle
    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
    try:
        win32gui.SetForegroundWindow(hwnd)
    except Exception:
        window.set_focus()
    time.sleep(0.6)


def click(x, y):
    win32api.SetCursorPos((int(x), int(y)))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)


def screenshot(window, output, crop=None):
    rect = window.rectangle()
    bounds = (rect.left, rect.top, rect.right, rect.bottom)
    if crop:
        left, top, right, bottom = crop
        bounds = (rect.left + left, rect.top + top, rect.left + right, rect.top + bottom)
    image = ImageGrab.grab(bbox=bounds, all_screens=True)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output)
    return rect


def search(group_id, output):
    window = find_qq_window()
    focus(window)
    rect = window.rectangle()
    click(rect.left + 145, rect.top + 65)
    keyboard.send_keys('^a')
    keyboard.send_keys(str(group_id), with_spaces=True)
    time.sleep(2.0)
    rect = screenshot(window, output)
    print(json.dumps({'ok': True, 'image': str(output), 'left': rect.left, 'top': rect.top, 'width': rect.width(), 'height': rect.height()}))


def open_group(group_id):
    window = find_qq_window()
    focus(window)
    rect = window.rectangle()
    click(rect.left + 145, rect.top + 65)
    keyboard.send_keys('^a')
    keyboard.send_keys(str(group_id), with_spaces=True)
    time.sleep(1.5)
    click(rect.left + 190, rect.top + 165)
    time.sleep(1.5)
    print(json.dumps({'ok': True, 'groupId': str(group_id)}))


def capture(output, crop):
    window = find_qq_window()
    focus(window)
    time.sleep(1.0)
    crop_values = [int(value) for value in crop.split(',')] if crop else None
    rect = screenshot(window, output, crop_values)
    print(json.dumps({'ok': True, 'image': str(output), 'left': rect.left, 'top': rect.top, 'width': rect.width(), 'height': rect.height(), 'crop': crop_values}))


def find_join_button(image):
    rgb_image = image.convert('RGB')
    width, height = rgb_image.size
    scan_height = min(height, 90)
    matching = set()

    for y in range(scan_height):
        for x in range(width):
            red, green, blue = rgb_image.getpixel((x, y))
            if red < 105 and 90 < green < 215 and blue > 180 and blue - red > 95:
                matching.add((x, y))

    components = []
    while matching:
        pending = [matching.pop()]
        component = []
        while pending:
            point = pending.pop()
            component.append(point)
            x, y = point
            for neighbor in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                if neighbor in matching:
                    matching.remove(neighbor)
                    pending.append(neighbor)
        components.append(component)

    for component in sorted(components, key=len, reverse=True):
        if len(component) < 120:
            continue
        left = min(point[0] for point in component)
        top = min(point[1] for point in component)
        right = max(point[0] for point in component)
        bottom = max(point[1] for point in component)
        button_width = right - left + 1
        button_height = bottom - top + 1

        if button_width < 45 or button_height < 15 or button_width > 180 or button_height > 55:
            continue

        return {
            'left': left,
            'top': top,
            'width': button_width,
            'height': button_height,
            'pixelCount': len(component),
            'centerX': left + button_width / 2,
            'centerY': top + button_height / 2,
        }

    return None


def find_end_call_button(image):
    rgb_image = image.convert('RGB')
    width, height = rgb_image.size
    scan_height = min(height, 70)
    horizontal_edges = []

    for y in range(scan_height):
        matching_x = []
        for x in range(width):
            red, green, blue = rgb_image.getpixel((x, y))
            if 175 <= red <= 235 and abs(red - green) < 6 and abs(green - blue) < 6:
                matching_x.append(x)

        if not matching_x:
            continue
        start = previous = matching_x[0]
        for x in matching_x[1:] + [None]:
            if x is not None and x == previous + 1:
                previous = x
                continue
            run_width = previous - start + 1
            if 40 <= run_width <= 120:
                horizontal_edges.append((start, previous, y))
            if x is not None:
                start = previous = x

    for top_left, top_right, top_y in horizontal_edges:
        for bottom_left, bottom_right, bottom_y in horizontal_edges:
            button_height = bottom_y - top_y + 1
            overlap = min(top_right, bottom_right) - max(top_left, bottom_left) + 1
            if 20 <= button_height <= 40 and overlap >= 35:
                left = min(top_left, bottom_left) - 10
                right = max(top_right, bottom_right) + 10
                return {
                    'left': max(0, left),
                    'top': top_y,
                    'width': min(width - 1, right) - max(0, left) + 1,
                    'height': button_height,
                    'centerX': (left + right) / 2,
                    'centerY': top_y + button_height / 2,
                }

    return None


def find_hangup_button(image):
    rgb_image = image.convert('RGB')
    width, height = rgb_image.size
    matching = set()
    for y in range(max(0, height - 140), height):
        for x in range(width):
            red, green, blue = rgb_image.getpixel((x, y))
            if red > 210 and green < 105 and blue < 125 and red - green > 120:
                matching.add((x, y))

    components = []
    while matching:
        pending = [matching.pop()]
        component = []
        while pending:
            point = pending.pop()
            component.append(point)
            x, y = point
            for neighbor in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                if neighbor in matching:
                    matching.remove(neighbor)
                    pending.append(neighbor)
        components.append(component)

    for component in sorted(components, key=len, reverse=True):
        left = min(point[0] for point in component)
        top = min(point[1] for point in component)
        right = max(point[0] for point in component)
        bottom = max(point[1] for point in component)
        button_width = right - left + 1
        button_height = bottom - top + 1
        if len(component) >= 500 and 30 <= button_width <= 70 and 30 <= button_height <= 70:
            return {
                'left': left,
                'top': top,
                'width': button_width,
                'height': button_height,
                'centerX': left + button_width / 2,
                'centerY': top + button_height / 2,
            }
    return None


def hangup(output):
    window = find_call_window()
    focus(window)
    rect = screenshot(window, output)
    with Image.open(output) as image:
        button = find_hangup_button(image)
    if not button:
        raise RuntimeError('未识别到红色退出通话按钮')
    click(rect.left + button['centerX'], rect.top + button['centerY'])
    time.sleep(1.5)
    print(json.dumps({'ok': True, 'button': button}))


def callscan(output, crop):
    window = find_qq_window()
    focus(window)
    time.sleep(0.8)
    crop_values = [int(value) for value in crop.split(',')]
    rect = screenshot(window, output, crop_values)
    with Image.open(output) as image:
        button = find_join_button(image)
        end_button = find_end_call_button(image)

    result = {
        'ok': True,
        'active': button is not None or end_button is not None,
        'image': str(output),
        'crop': crop_values,
        'windowWidth': rect.width(),
        'windowHeight': rect.height(),
    }
    if button:
        result['button'] = button
        result['joinX'] = crop_values[0] + button['centerX']
        result['joinY'] = crop_values[1] + button['centerY']
    if end_button:
        result['endButton'] = end_button
        result['joined'] = button is None
        if button is None:
            result['leaveX'] = crop_values[0] + end_button['centerX']
            result['leaveY'] = crop_values[1] + end_button['centerY']
    print(json.dumps(result))


def click_relative(x, y):
    window = find_qq_window()
    focus(window)
    rect = window.rectangle()
    click(rect.left + float(x), rect.top + float(y))
    time.sleep(1.2)
    print(json.dumps({'ok': True}))


def probe():
    window = find_qq_window()
    rect = window.rectangle()
    print(json.dumps({'ok': True, 'width': rect.width(), 'height': rect.height(), 'pid': window.process_id()}))


parser = argparse.ArgumentParser()
parser.add_argument('command', choices=['probe', 'search', 'open', 'capture', 'callscan', 'hangup', 'click'])
parser.add_argument('--group')
parser.add_argument('--output')
parser.add_argument('--x')
parser.add_argument('--y')
parser.add_argument('--crop')
args = parser.parse_args()

try:
    if args.command == 'probe': probe()
    elif args.command == 'search': search(args.group, args.output)
    elif args.command == 'open': open_group(args.group)
    elif args.command == 'capture': capture(args.output, args.crop)
    elif args.command == 'callscan': callscan(args.output, args.crop)
    elif args.command == 'hangup': hangup(args.output)
    else: click_relative(args.x, args.y)
except Exception as error:
    print(json.dumps({'ok': False, 'error': str(error)}))
    raise SystemExit(1)
