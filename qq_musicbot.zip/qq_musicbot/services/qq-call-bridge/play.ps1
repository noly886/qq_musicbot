param(
  [Parameter(Mandatory=$true)][string]$File,
  [Parameter(Mandatory=$true)][string]$InitializedFile,
  [Parameter(Mandatory=$true)][string]$ReadyFile
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationCore
$probe = New-Object System.Windows.Media.MediaPlayer
$probe.Volume = 0.0
$probe.Open([Uri]$File)
$probe.Play()
Start-Sleep -Milliseconds 400
Set-Content -LiteralPath $InitializedFile -Value 'initialized'
for ($attempt = 0; $attempt -lt 150 -and -not (Test-Path -LiteralPath $ReadyFile); $attempt++) {
  Start-Sleep -Milliseconds 100
}
if (-not (Test-Path -LiteralPath $ReadyFile)) { throw '音频路由准备超时' }
$probe.Stop()
$probe.Close()
Start-Sleep -Milliseconds 300
$player = New-Object System.Windows.Media.MediaPlayer
$player.Open([Uri]$File)
$player.Volume = 0.85
$script:mediaCompleted = $false
$player.add_MediaEnded({ $script:mediaCompleted = $true })
$player.add_MediaFailed({ $script:mediaCompleted = $true })
$player.Play()
$waited = 0
while (-not $script:mediaCompleted -and -not $player.NaturalDuration.HasTimeSpan -and $waited -lt 100) {
  Start-Sleep -Milliseconds 100
  $waited++
}
if (-not $script:mediaCompleted -and $player.NaturalDuration.HasTimeSpan) {
  Start-Sleep -Milliseconds ([Math]::Ceiling($player.NaturalDuration.TimeSpan.TotalMilliseconds + 500))
} elseif (-not $script:mediaCompleted) {
  while (-not $script:mediaCompleted) { Start-Sleep -Milliseconds 200 }
}
$player.Stop()
$player.Close()
