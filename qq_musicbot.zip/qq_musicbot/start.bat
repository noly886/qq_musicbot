@echo off
cd /d "%~dp0"
if not exist node_modules call npm.cmd install
if not exist services\KuGouMusicApi-main\node_modules call npm.cmd install --omit=dev --prefix services\KuGouMusicApi-main
node src/server.js
pause
